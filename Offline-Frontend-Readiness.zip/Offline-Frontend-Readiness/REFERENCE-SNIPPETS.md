# Offline request reminders

These are fragments to adapt inside your existing Vue components, not a complete application.
Your current App.vue, Login.vue, Register.vue, auth.js and Equipment.vue are the primary working references.

## Shared authentication - src/auth.js

```js
import { ref } from "vue";
export const token = ref("");
export const currentUser = ref(null);
```

App.vue restores sessionStorage and verifies GET me before revealing protected content.

## Environment

```env
VITE_API_BASE_URL=http://localhost/geardesk-api/index.php
```

```js
const API_URL = import.meta.env.VITE_API_BASE_URL;
```

Restart Vite after changes. VITE variables are public browser configuration, never database secrets.

## Login response -> shared state -> parent event

After checking response.ok and the documented response shape:

```js
sessionStorage.setItem("geardesk_token", result.data.access_token);
token.value = result.data.access_token;
currentUser.value = result.data.user;
password.value = "";
emit("logged-in");
```

Use the form's @submit.prevent handler. The submit button needs type=submit, without a second click handler. Use type=email and type=password. Never trim passwords.

## GET page and applied search

Use your existing currentPage/itemsPerPage/appliedSearch refs and imported token:

```js
const params = new URLSearchParams({
  resource: "equipment",
  page: String(currentPage.value),
  per_page: String(itemsPerPage)
});

if (appliedSearch.value) {
  params.set("search", appliedSearch.value.trim());
}

const response = await fetch(API_URL + "?" + params, {
  headers: { Authorization: "Bearer " + token.value }
});

if (response.status === 401) {
  // Call your existing expired-session cleanup/navigation handler.
  endExpiredSession();
  return;
}

const result = await response.json();
if (!response.ok) throw new Error(result.message || "Unable to load.");

equipment.value = result.data;
totalEquipment.value = result.meta.total;
currentPage.value = result.meta.page;
totalPages.value = result.meta.total_pages;
hasLoaded.value = true;
```

Place requests in try/catch and reset loading in finally. Reset page to 1 when applying search/filter/sort. Sorting needs documented API support; the base GearDesk API does not provide dynamic name/price sorting.

## PATCH reminder - adapt your existing editSupply flow

In the older supply project's src/App.vue, find openEditModal and editSupply.

- JavaScript: copy selectedSupply, editable field refs, openEditModal, validation and editSupply.
- HTML: copy the Edit button and the showEditModal form, outside the v-for.
- CSS: copy .modal, .editModal and .editSupply-card, checking the classes actually used in your local corrected template.
- Change the route, method and field names to the assessment's API contract.

For GearDesk's documented API, a partial-update request inside your async edit handler is:

```js
const response = await fetch(
  API_URL + "?resource=equipment&id=" + encodeURIComponent(selectedId.value),
  {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer " + token.value
    },
    body: JSON.stringify({
      name: editName.value.trim(),
      daily_rate: Number(editRate.value),
      available_units: Number(editUnits.value)
    })
  }
);

if (response.status === 401) {
  endExpiredSession();
  return;
}

const result = await response.json();
if (!response.ok) throw new Error(result.message || "Unable to update.");

await getEquipment();
showEditModal.value = false;
```

The refs selectedId/editName/editRate/editUnits/showEditModal must exist in your edit component; this fragment does not declare them. Validate nonblank numeric inputs before Number(), since Number("") is 0. Handle protected-request 401 through your existing session handler. If the new API documents POST/PUT for an update, use that contract instead of assuming PATCH.

## POST and DELETE reuse pointers

POST: older supply src/App.vue -> addSupplies; copy its field refs, Add button, form and .addSupply-Card/.modal CSS. Let the backend generate IDs unless docs say otherwise. Close only on success.

DELETE: older supply src/App.vue -> deleteSupply and deleting. Confirm the intended record before sending. For GearDesk:

```js
const response = await fetch(
  API_URL + "?resource=equipment&id=" + encodeURIComponent(id),
  {
    method: "DELETE",
    headers: { Authorization: "Bearer " + token.value }
  }
);

// Handle 401 through the existing session handler first.
if (response.status === 401) {
  endExpiredSession();
  return;
}

if (!response.ok) {
  const result = await response.json();
  throw new Error(result.message || "Unable to delete.");
}

// Successful DELETE is 204: there is no JSON body to parse.
await getEquipment();
```

After deleting the last record on the final page, correct an out-of-range page and fetch again. This is an integration fragment, not a replacement for your full delete handler.

## HTML and CSS reminders

```html
<!-- Use your existing refs and submit handler. -->
<form @submit.prevent="editSupply">
  <label for="edit-name">Name</label>
  <input id="edit-name" v-model="editName" required />
  <button type="submit" :disabled="updating">Save changes</button>
</form>
```

In Vue script, refs use .value. In templates, Vue unwraps refs. Show statusMessage inside the relevant form. A v-if=hasLoaded wrapper needs hasLoaded=true after a successful GET. Keep Add/Edit modals outside v-for.

Global CSS: src/assets/main.css imported by src/main.js. Per-page CSS: that page's style scoped block. Use the same class names in the template and stylesheet.

## Save-before-offline reminders

- Copy YOUR final working code from the conversation into the actual local files; save them.
- Keep the GearDesk project and earlier supply App.vue locally. The backend ZIP does not contain your Vue frontend solution.
- Save the optional search/sort PHP changes separately if you applied them; the original backend download has fixed ID ordering.
- Keep original/reference projects separate from the new starter. Adapt one feature at a time, testing each request in Network.
