# Offline Frontend Readiness - 30-Minute Guide

Prepared for your Vue + supplied API assessment practice. Windows laptop. 28 October 2026.

**Goal:** have the tools, installed dependencies, backend, documentation and your own snippets available locally. The strongest check is disconnecting the Internet and successfully running the frontend and backend. A different assessment API can still require different setup.

## 1. Use your remaining 30 minutes

| Time | Do this first |
| --- | --- |
| 0-5 min | Check Node/npm, Git, VS Code and XAMPP. Keep versions that already work. Download only missing installers. |
| 5-15 min | Install project dependencies while online. Prepare one minimal Vue starter and keep your working GearDesk reference project. |
| 15-20 min | Save this guide, your actual Vue source, API documentation, SQL, backend .env, mockups and essential documentation. |
| 20-27 min | Disconnect the Internet. Restart Vite and XAMPP, test login, equipment loading, pagination and a production build. |
| 27-30 min | Reconnect only to fix a failed check or download a missing dependency. Make a backup to USB/another local folder. |

If time is running out, prioritize the working project, its node_modules, local PHP API/database and this guide over installing optional extensions.

## 2. Installation checklist - complete while online

| Priority | Install / prepare | How to verify |
| --- | --- | --- |
| Essential | Node.js with npm | `node -v` and `npm -v` |
| Essential | VS Code desktop | Launch it and open your project; `code --version` if its command is on PATH |
| Essential | Vue and Vite inside each project | `npm install`, then `npm run dev` and `npm run build` |
| Essential | Git for Windows | `git --version` and `git status` in your repository |
| Essential for our PHP API | XAMPP: Apache, MySQL/MariaDB, PHP, phpMyAdmin | Start Apache/MySQL; open the health endpoint |
| Essential | A local browser with DevTools | Open localhost; use F12 > Network and Console |
| Useful | Vue (Official), extension ID `Vue.volar` | Open a .vue file; confirm completion/diagnostics load while online |
| Optional | Prettier, extension ID `esbenp.prettier-vscode` | Format a .vue file now; verify formatting also works disconnected |
| Optional | ESLint, extension ID `dbaeumer.vscode-eslint` | Use if your project already has ESLint configured and installed |
| Optional | JSON Server in your old practice project | Use the existing `npm run api` script; needed only for that practice backend |

Current Vue Quick Start requires Node `^22.18.0 || >=24.12.0`. If you must install Node, choose a compatible LTS release. Keep your already-tested compatible installation rather than spending the preparation window upgrading it.

**Vue is a project dependency.** You do not need a global Vue installation. Node/npm, VS Code, Git and XAMPP are separate tools. Browser `fetch()` needs no npm package. A Vite project uses `npm run dev`; Live Server is unnecessary for it.

Official download locations, to use while online:

- Node: https://nodejs.org/en/download
- VS Code: https://code.visualstudio.com/download
- Git for Windows: https://git-scm.com/install/windows
- XAMPP: https://www.apachefriends.org/download.html
- Vue (Official): https://marketplace.visualstudio.com/items?itemName=Vue.volar

Optional extension commands, if the `code` command works:

```powershell
code --install-extension Vue.volar
code --install-extension esbenp.prettier-vscode
code --install-extension dbaeumer.vscode-eslint
code --list-extensions --show-versions
```

Install extensions and open them now. For an offline reinstall backup, use VS Code's Extensions view > right-click the extension > Download VSIX. Install it later through Extensions: Install from VSIX. Keep any required companion extensions too.

If download time permits, keep the matching Windows installers (.msi/.exe) and extension VSIX files in a local Setup folder or USB. Installing packages today does not put the original installers in that backup automatically.

## 3. Prepare the actual projects, not just installers

### Your working GearDesk reference

- [ ] Save all open files in VS Code.
- [ ] In its folder, confirm `package.json` exists before running npm commands.
- [ ] Run `npm install` online if dependencies are missing. Keep the existing lockfile.
- [ ] Run `npm run dev` and confirm the browser loads.
- [ ] Run `npm run build` and resolve build errors now.
- [ ] Keep **node_modules**, package.json, package-lock.json, src, public, index.html and Vite configuration in your local preparation backup.
- [ ] Keep your .env.local for practice; database credentials stay in PHP's backend .env.
- [ ] Use the same Windows machine/architecture for a copied node_modules folder. Reinstall online for a different platform.

Your offline preparation backup can include node_modules. The final assessment submission normally excludes it; follow the submission instructions.

### A minimal starter, while still online

Create it in a separate parent folder, never over your working GearDesk project:

```powershell
npm create vue@latest
# Choose a name such as assessment-starter.
# Use JavaScript; keep optional features minimal unless required.
cd assessment-starter
npm install
npm run build
npm run dev
```

Stop Vite with Ctrl+C after testing. Keep this installed starter locally. New scaffolding or an uncached `npx` command can need Internet access; do not rely on generating it after disconnection.

### npm offline traps

- package.json and package-lock.json describe dependencies; they do not contain the installed packages.
- Keep a tested node_modules folder. Check `npm config get cache` if you also want to back up the npm cache.
- `npm install --offline` can use only what is already cached. A missing dependency still causes failure.
- `--prefer-offline` can contact the network; it is not a guarantee of offline operation.
- **Do not run npm ci on your only working offline copy.** It removes node_modules first. If testing `npm ci --offline`, use a disposable copy with the lockfile and complete cache; install scripts can have additional requirements.
- Avoid changing dependency versions, adding libraries, clearing the npm cache, or deleting node_modules after going offline.
- Check `npm run` to see the scripts actually available. Your JSON Server practice may use `npm run api`; GearDesk's PHP backend runs through XAMPP instead.

## 4. Prepare the local API and assets

- [ ] Copy the GearDesk PHP API to `C:\xampp\htdocs\geardesk-api`.
- [ ] Import database/geardesk.sql through phpMyAdmin.
- [ ] Check backend .env credentials and its allowed frontend origins.
- [ ] Check frontend .env.local, for example:

```env
VITE_API_BASE_URL=http://localhost/geardesk-api/index.php
```

- [ ] Restart Vite after editing .env.local.
- [ ] Save API-DOCUMENTATION.md and LEARN-AUTH-FIRST.md locally.
- [ ] Export the current practice database through phpMyAdmin if you want to preserve accounts/edits. The original seed SQL does not contain accounts you registered afterward.
- [ ] Save images, fonts, icons, CSS and JS locally. Check for CDN links and remote imports. Use system fonts if time is short.
- [ ] If you use Bootstrap/Tailwind/a UI library, install and test its actual dependencies now. Avoid introducing a new stack during this preparation window.

Health URL: http://localhost/geardesk-api/index.php?resource=health

A protected equipment URL opened directly in the address bar should return 401 without the token. A health response should report database connected and authentication bearer.

**An Internet-hosted assessment API is not made offline by installing XAMPP.** Obtain the supplied backend/data or confirm the assessment's local network arrangement. localhost can work with Internet disconnected; a LAN server still requires that local network connection.

## 5. Disconnect and prove readiness

- [ ] Stop the existing dev server, disconnect Wi-Fi/Ethernet Internet, then reopen VS Code and a new terminal.
- [ ] Start Apache and MySQL in XAMPP.
- [ ] In the Vue project run `npm run dev`; open the printed localhost URL.
- [ ] Log in with a fictional account and confirm GET me and GET equipment succeed.
- [ ] Go to page 2, then refresh the browser and verify session restoration.
- [ ] Confirm wrong-password messages appear and Logout returns to Login.
- [ ] Stop Vite and run `npm run build` while still disconnected.
- [ ] Optionally run `npm run preview` and open its printed URL; its origin must be allowed by the backend.
- [ ] Confirm local docs, mockups and reference source files open without Internet.
- [ ] Check Network for essential requests going to external domains. Replace required remote assets with local files.

If a check fails, reconnect now and fix that specific dependency. This rehearsal reduces surprises; a successful installer download alone is not the test.

## 6. Where your existing snippets live

Paths below are relative to YOUR local project. Save your latest working versions now. They are reminders based on our reviewed code, not a claim that every suggested change has been pasted into your local files.

| Feature | Project and file | JavaScript to find | HTML / CSS to copy with it |
| --- | --- | --- | --- |
| Navigation, restore session, logout | GearDesk: src/App.vue | verifySession, openPage, clearSession, logout | nav, component events, protected Equipment condition, scoped nav styles |
| Shared auth | GearDesk: src/auth.js | token and currentUser refs | No template or CSS |
| Login | GearDesk: src/pages/Login.vue | login, saving, token assignment before emit | login-form, status message, email/password inputs; matching scoped styles |
| Registration | GearDesk: src/pages/Register.vue | registerPracticeAccount, password confirmation, registered event | register-form, field errors, submit button, scoped styles |
| GET records | GearDesk: src/pages/Equipment.vue | getEquipment, requestToken, result.data, result.meta | equipment table, v-for, loading/empty/error states; table-container styles |
| Server pagination | GearDesk: src/pages/Equipment.vue | currentPage, totalPages, itemsPerPage, changePage | Previous/Next, page count and showing-range text |
| Search/sort | GearDesk: src/pages/Equipment.vue, IF you pasted the last changes | applyFilters, clearFilters, appliedSearch, appliedSort, URLSearchParams | equipment-filters form and its scoped CSS |
| Create | Earlier Campus Supply practice: src/App.vue | addSupplies, addName/addPrice/addCategory/addStock, showAddModal | form @submit.prevent=addSupplies; addSupply-Card and modal styles |
| Update | Earlier Campus Supply practice: src/App.vue | openEditModal, editSupply, selectedSupply, editName/editStock/editCategory | edit button, showEditModal, form @submit.prevent=editSupply; editSupply-card, editModal and modal styles |
| Delete | Earlier Campus Supply practice: src/App.vue | deleteSupply, deleting; search DELETE | delete button and confirmation; delete-Button styles |
| Global light theme | GearDesk: src/assets/main.css | Check its import in src/main.js | root colors, body, app container, inputs and buttons |
| Cart/totals/localStorage patterns | Earlier Online Palengke project | VS Code Ctrl+Shift+F for localStorage, subtotal, checkout | Copy the matching UI only if the new task needs it |

The supply function/class names were checked in your earlier pasted source. That older snapshot still contains issues we subsequently discussed, so use your corrected local copy as the starting point. GearDesk create/edit/delete were not completed together in this thread; the supply App.vue is your earlier CRUD reference.

**Copy a complete feature:** its imports/refs, open/save handler, template, CSS and parent event wiring. Keep modals outside v-for. Adjust field names and routes to the new API. A supply PATCH is not automatically a valid competition-entry PATCH.

Use VS Code Ctrl+Shift+F across the old project. Search `PATCH`, `DELETE`, `openEditModal`, `showAddModal`, `@submit.prevent`, `.modal`, or `sessionStorage`. The separate REFERENCE-SNIPPETS.md contains short offline request reminders.

## 7. Competition-app adaptation sheet

The competition scenario is your expectation; confirm its actual fields and operations from the supplied brief.

| Check the new API docs | GearDesk example | Write the assessment's actual value |
| --- | --- | --- |
| Base URL / frontend env key | VITE_API_BASE_URL | __________ |
| Login and registration routes | ?resource=login / register | __________ |
| Token location | data.access_token | __________ |
| Authorization scheme | Bearer token header | __________ |
| List resource and response array | equipment / result.data | __________ |
| Record identifier | id | __________ |
| Writable fields and JSON types | name, category_id, daily_rate, available_units | __________ |
| Pagination query and response | page/per_page; meta.total_pages | __________ |
| Search / filter / sort support | search/category_id; sort is OUR practice extension | __________ |
| Update method / delete response | PATCH; DELETE 204 | __________ |

Request the documented page, render its returned array, and use its metadata. Search/sort must cover the matching dataset before pagination. The original GearDesk API supports name search and category filtering; name/price sorting works only after applying our optional PHP extension. Do not assume the assessment uses the same parameters or allows backend edits.

## 8. Short working order during the event

1. Read mockup and API docs; write the adaptation sheet above.
2. Start the supplied backend, set the public API URL, test one endpoint.
3. Complete Register/Login/Bearer flow only as required by those docs.
4. Load and display records; add pagination, loading, empty and error states.
5. Add the required create/edit/delete forms, then search/filter/sort as documented.
6. Test persistence after refresh, invalid inputs, failed requests and mobile width.
7. Run the build, finish README/test results and save Git commits.

Git works locally for status/add/commit/log. Push/pull/clone need the remote to be reachable. Check an existing identity with `git config --get user.name` and `git config --get user.email`; set a project-local name/email if required and currently missing.

```powershell
git status
git diff
git add src
git commit -m "Implement equipment listing"
git log --oneline -5
```

Use an explicit file list as needed. Keep real credentials, passwords, access tokens and node_modules out of Git. Inspect staged files before committing.

## 9. Save documentation while online

Save this guide and REFERENCE-SNIPPETS.md first. Then, if time permits, print essential pages to PDF or use Save Page As > Webpage, Complete; open the saved result with Internet disconnected. Bookmarks and an open browser tab are not an offline documentation pack.

- Vue Quick Start: https://vuejs.org/guide/quick-start.html
- Vue form bindings: https://vuejs.org/guide/essentials/forms.html
- Vue computed: https://vuejs.org/guide/essentials/computed.html
- Vue list rendering: https://vuejs.org/guide/essentials/list.html
- Vue lifecycle: https://vuejs.org/guide/essentials/lifecycle.html
- Fetch and response handling: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
- npm offline setting: https://docs.npmjs.com/cli/v11/using-npm/config/#offline
- npm ci behavior: https://docs.npmjs.com/cli/v11/commands/npm-ci/
- VS Code offline extension installation: https://code.visualstudio.com/docs/configure/extensions/extension-marketplace
- Local Git help: `git help -a`; try `git help commit` while online to confirm the installed help viewer works.

Local source/reference copies are especially useful because ChatGPT, hosted code editors, AI extensions, GitHub and online documentation may be unavailable after disconnection.

## 10. Rapid troubleshooting card

| Symptom | First check |
| --- | --- |
| npm Missing script | `npm run`; check you are in the folder containing package.json |
| vite not recognized / module missing | Existing node_modules; install missing dependencies while still online |
| PowerShell blocks npm.ps1 | Try `npm.cmd run dev` in the project, or use Command Prompt |
| HTML instead of JSON | API URL/path and Apache port; inspect Network > Response |
| 401 | Actual returned token, Bearer header, expiry and stored session |
| 422 | API field errors, exact field names and numeric JSON types |
| 503 | MySQL, imported SQL and backend database credentials |
| CORS | Exact Vite origin in backend allowed origins; allow Authorization |
| Loading stays visible | Network status, Console, hasLoaded=true on success, loading=false in finally |
| Blank list after successful response | Correct response array path; v-if condition and v-for binding |
| Black page | Global CSS import in main.js and starter dark-theme rules |
| DELETE succeeds but JS errors | 204 has no body; skip response.json() |

**Last check before disconnecting: your actual source, dependencies, backend, SQL and docs must be on the laptop. Cloud links alone are not the backup.**
