Open OPEN-FIRST.html in your browser. It includes the preparation checklist and snippet reminders.
START-HERE.md and REFERENCE-SNIPPETS.md open in VS Code.
The pack contains documentation, not installers, node_modules, your Vue project or the PHP backend.
Save your actual working frontend and backend on your laptop before disconnecting.
