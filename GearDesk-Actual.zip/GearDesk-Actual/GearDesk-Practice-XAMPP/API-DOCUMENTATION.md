# GearDesk Authentication API - supplied contract

Base URL: `http://localhost/geardesk-api/index.php`

Routes use query strings: login is **`?resource=login`**, not `/login`.
Follow the assessor's actual routes when consuming a different API.
Send Accept: application/json; send Content-Type: application/json for JSON bodies.
No cookies or `credentials: "include"` setting is needed.

| Operation | Method | Append to base URL | Token? | Success |
| --- | --- | --- | --- | --- |
| Health | GET | `?resource=health` | No | 200 |
| Register | POST | `?resource=register` | No | 201 |
| Login | POST | `?resource=login` | No | 200 |
| Current user | GET | `?resource=me` | Yes | 200 |
| Logout | POST | `?resource=logout` | Yes | 200 |
| Categories | GET | `?resource=categories` | Yes | 200 |
| List equipment | GET | `?resource=equipment&page=1&per_page=5` | Yes | 200 |
| One item | GET | `?resource=equipment&id=1` | Yes | 200 |
| Create | POST | `?resource=equipment` | Yes | 201 |
| Edit | PATCH | `?resource=equipment&id=1` | Yes | 200 |
| Delete | DELETE | `?resource=equipment&id=1` | Yes | 204, no body |

Every protected request sends the raw token returned by Login:

```http
Authorization: Bearer YOUR_ACCESS_TOKEN
```

One space follows Bearer. Do not quote the token, put it in the URL, or use the database password.
The practice token is an opaque string, not a JWT to decode.

## Register

`POST ?resource=register`

```json
{
  "name": "Practice Staff",
  "email": "staff@example.test",
  "password": "Practice123!",
  "password_confirmation": "Practice123!"
}
```

Name: trimmed 1-80 characters. Email: valid, at most 190 characters, normalized to lowercase,
unique. Password: 8-72 bytes (use ASCII for this exercise). Confirmation must match exactly.
Do not send id, a token, or database credentials.

201 response:

```json
{
  "message": "Account created. Please log in.",
  "data": { "id": 1, "name": "Practice Staff", "email": "staff@example.test" }
}
```

**Registration does not return a token or log you in.** Log in next.
Invalid form: 422. Duplicate email: 409.

## Login

`POST ?resource=login`

```json
{ "email": "staff@example.test", "password": "Practice123!" }
```

200 response (token below is illustrative):

```json
{
  "message": "Logged in.",
  "data": {
    "access_token": "0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef",
    "token_type": "Bearer",
    "expires_in": 3600,
    "user": { "id": 1, "name": "Practice Staff", "email": "staff@example.test" }
  }
}
```

Read **result.data.access_token**, not result.token. expires_in is seconds.
Wrong email/password: 401. Malformed fields: 422. Show the error; do not retry in a loop.

## Verify a saved session

`GET ?resource=me`, with Authorization header.

```json
{ "data": { "id": 1, "name": "Practice Staff", "email": "staff@example.test" } }
```

On frontend reload, verify a saved token before revealing inventory. On 200, use result.data
as the current user. On 401, discard the token and show Login. A network failure / 503 does not
prove the token invalid: keep it and offer Retry.

## Categories

`GET ?resource=categories`, with Authorization header.

```json
{
  "data": [
    { "id": 1, "name": "Audio" },
    { "id": 2, "name": "Lighting" },
    { "id": 3, "name": "Presentation" },
    { "id": 4, "name": "Power" }
  ]
}
```

Send the numeric id, not category name, in equipment saves.
Vue: `<option :value="category.id">` preserves a numeric value.

## List, search, and server pagination

`GET ?resource=equipment&page=1&per_page=5&search=projector&category_id=3`

| Parameter | Rule |
| --- | --- |
| page | Positive integer, default 1, maximum 1000000 |
| per_page | Integer 1-50, default 5; use 5 for this exercise |
| search | Optional name substring; case-insensitive under supplied DB collation |
| category_id | Optional positive category ID; omit for All categories |

Filters combine with AND. Reset page to 1 on filter/search changes. Use URLSearchParams for
encoding; additional parameters follow `?resource=equipment` with `&`.
Sort: ascending ID. Fresh import: 17 items, four pages (5/5/5/2).

For brevity, here is the complete response for page 4:

```json
{
  "data": [
    { "id": 16, "name": "Portable Monitor", "category_id": 3,
      "category_name": "Presentation", "daily_rate": 650, "available_units": 3 },
    { "id": 17, "name": "UPS Backup Unit", "category_id": 4,
      "category_name": "Power", "daily_rate": 500, "available_units": 2 }
  ],
  "meta": { "page": 4, "per_page": 5, "total": 17, "total_pages": 4 }
}
```

List = result.data; pagination = result.meta. **Do not slice the returned page again in Vue.**
No matches: data [], total 0, total_pages 0. Show an empty state instead of Page 1 of 0.
An out-of-range page returns empty data with real totals: correct the page and fetch again.
Deleting both items on page 4 leaves 15 items, so request page 3.

## Create

`POST ?resource=equipment`, with Authorization and Content-Type headers.

```json
{
  "name": "Conference Microphone",
  "category_id": 1,
  "daily_rate": 275.5,
  "available_units": 3
}
```

201 response:

```json
{
  "message": "Equipment created.",
  "data": { "id": 18, "name": "Conference Microphone", "category_id": 1,
    "category_name": "Audio", "daily_rate": 275.5, "available_units": 3 }
}
```

Backend generates IDs; category_name is read-only.

| Field | Rule |
| --- | --- |
| name | Trimmed string, 1-80 characters |
| category_id | JSON integer matching a supplied category |
| daily_rate | JSON number > 0, maximum 999999.99, at most two decimals |
| available_units | JSON integer 0-9999; zero is valid |

Number strings such as "275.50" are rejected. Convert numeric form values before JSON.stringify.

## Edit and delete

`PATCH ?resource=equipment&id=18`, with Authorization and Content-Type headers.
Send a nonempty subset of writable fields:

```json
{ "name": "Updated Conference Microphone", "available_units": 0 }
```

200 returns message and updated equipment in data.
`DELETE ?resource=equipment&id=18` with Authorization returns **204 No Content**.
Do not call response.json() on successful DELETE. Unknown record: 404.

## Logout

`POST ?resource=logout`, Authorization header; no body required.

```json
{ "message": "Logged out." }
```

The backend revokes this token. Clear frontend state/sessionStorage and private data, then show
Login. Reusing the old token must give 401. An already-invalid-token 401 also clears local state.
For network/server errors, show failure and offer Retry; do not claim server revocation succeeded.

## Errors

```json
{
  "message": "Please check the form fields.",
  "errors": { "available_units": "Enter a whole number from 0 to 9999." }
}
```

| Status | Meaning |
| --- | --- |
| 400 | Invalid query or JSON |
| 401 on Login | Wrong credentials; stay on Login |
| 401 on protected request | Missing/expired/revoked token; clear session, show Login |
| 403 | Frontend origin not allowed |
| 404 | Unknown endpoint / record |
| 405 | Wrong HTTP method |
| 409 | Duplicate registration email |
| 415 | Wrong JSON Content-Type |
| 422 | Invalid input; show message/errors and retain ordinary inputs |
| 503 | Database unavailable; offer Retry |

fetch() does not automatically throw for HTTP errors: check response.ok/status.
Network failure can throw before a response exists.

## Backend details and expiry practice

Random 64-character tokens are stored as SHA-256 hashes. Passwords use PHP password_hash and
password_verify. Tokens expire after 60 minutes by default. There is no refresh-token endpoint.
All signed-in users share inventory. This custom learning API uses Bearer headers, not a full OAuth server.

To test expiry: set TOKEN_TTL_MINUTES=1 in backend .env, obtain a NEW login token, wait over
60 seconds, then call me. Existing tokens retain their original expiry. Restore 60 afterward.

References: https://www.rfc-editor.org/rfc/rfc6750.html
and https://www.php.net/manual/en/book.password.php
