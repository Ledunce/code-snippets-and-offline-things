<?php
// The environment belongs to this PHP backend, never to the Vue application.
declare(strict_types=1);

function configuration(): array
{
    $path = __DIR__ . '/.env';
    if (!is_file($path)) {
        throw new RuntimeException('Missing backend .env file.');
    }
    $config = parse_ini_file($path, false, INI_SCANNER_RAW);
    if ($config === false) {
        throw new RuntimeException('Invalid backend .env file.');
    }
    foreach (['DB_HOST', 'DB_PORT', 'DB_DATABASE', 'DB_USERNAME'] as $key) {
        if (!isset($config[$key]) || $config[$key] === '') {
            throw new RuntimeException('Incomplete backend configuration.');
        }
    }
    return $config;
}

function database(array $config): PDO
{
    $dsn = 'mysql:host=' . $config['DB_HOST'] . ';port=' . $config['DB_PORT']
        . ';dbname=' . $config['DB_DATABASE'] . ';charset=utf8mb4';
    $db = new PDO($dsn, $config['DB_USERNAME'], $config['DB_PASSWORD'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $db->exec("SET time_zone = '+00:00'");
    return $db;
}
