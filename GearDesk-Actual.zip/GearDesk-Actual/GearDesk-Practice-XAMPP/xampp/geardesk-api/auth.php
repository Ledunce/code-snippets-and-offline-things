<?php
declare(strict_types=1);

function publicUser(array $row): array
{
    return ['id' => (int) $row['id'], 'name' => $row['name'], 'email' => $row['email']];
}

function registerUser(PDO $db): void
{
    $body = jsonBody();
    $errors = [];
    $allowed = ['name', 'email', 'password', 'password_confirmation'];
    foreach (array_keys($body) as $field) {
        if (!in_array($field, $allowed, true)) {
            $errors[$field] = 'This field is not accepted.';
        }
    }
    $name = is_string($body['name'] ?? null) ? trim($body['name']) : '';
    $email = is_string($body['email'] ?? null) ? strtolower(trim($body['email'])) : '';
    $password = $body['password'] ?? null;
    if ($name === '' || preg_match_all('/./us', $name) > 80) {
        $errors['name'] = 'Enter a name of 1 to 80 characters.';
    }
    if (strlen($email) > 190 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Enter a valid email address, up to 190 characters.';
    }
    // PASSWORD_DEFAULT uses bcrypt on the targeted PHP 8.x installations.
    if (!is_string($password) || strlen($password) < 8 || strlen($password) > 72 || strpos($password, "\0") !== false) {
        $errors['password'] = 'Use a password of 8 to 72 bytes (8 to 72 ASCII characters).';
    }
    if (!is_string($body['password_confirmation'] ?? null)
        || $password !== $body['password_confirmation']) {
        $errors['password_confirmation'] = 'Passwords must match.';
    }
    if ($errors !== []) {
        fail(422, 'Please check the registration fields.', $errors);
    }
    try {
        $statement = $db->prepare('INSERT INTO users (name, email, password_hash) VALUES (:name, :email, :password_hash)');
        $statement->execute(['name' => $name, 'email' => $email,
            'password_hash' => password_hash($password, PASSWORD_DEFAULT)]);
    } catch (PDOException $error) {
        if ((int) ($error->errorInfo[1] ?? 0) === 1062) {
            fail(409, 'This email is already registered.', ['email' => 'Use another email or log in.']);
        }
        throw $error;
    }
    respond(201, ['message' => 'Account created. Please log in.', 'data' => [
        'id' => (int) $db->lastInsertId(), 'name' => $name, 'email' => $email,
    ]]);
}

function loginUser(PDO $db, array $config): void
{
    $body = jsonBody();
    $email = is_string($body['email'] ?? null) ? strtolower(trim($body['email'])) : '';
    $password = $body['password'] ?? null;
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !is_string($password)
        || $password === '' || strlen($password) > 72 || strpos($password, "\0") !== false) {
        fail(422, 'Enter a valid email and password.');
    }
    $statement = $db->prepare('SELECT id, name, email, password_hash FROM users WHERE email = :email');
    $statement->execute(['email' => $email]);
    $user = $statement->fetch();
    // A fixed dummy hash keeps password verification in the unknown-email path too.
    $dummyHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi';
    $valid = password_verify($password, $user === false ? $dummyHash : $user['password_hash']);
    if (!$valid || $user === false) {
        fail(401, 'The email or password is incorrect.');
    }
    $token = bin2hex(random_bytes(32));
    $minutes = filter_var($config['TOKEN_TTL_MINUTES'] ?? '60', FILTER_VALIDATE_INT,
        ['options' => ['min_range' => 1, 'max_range' => 1440]]);
    if ($minutes === false) {
        throw new RuntimeException('Invalid TOKEN_TTL_MINUTES configuration.');
    }
    $expiresIn = $minutes * 60;
    $statement = $db->prepare('DELETE FROM auth_tokens WHERE user_id = :user_id AND expires_at <= UTC_TIMESTAMP()');
    $statement->execute(['user_id' => $user['id']]);
    $statement = $db->prepare('INSERT INTO auth_tokens (user_id, token_hash, expires_at) VALUES (:user_id, :token_hash, :expires_at)');
    $statement->execute(['user_id' => $user['id'], 'token_hash' => hash('sha256', $token),
        'expires_at' => gmdate('Y-m-d H:i:s', time() + $expiresIn)]);
    respond(200, ['message' => 'Logged in.', 'data' => [
        'access_token' => $token, 'token_type' => 'Bearer', 'expires_in' => $expiresIn,
        'user' => publicUser($user),
    ]]);
}

function requireAuthenticated(PDO $db): array
{
    $authorization = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if ($authorization === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp($name, 'Authorization') === 0) {
                $authorization = $value;
                break;
            }
        }
    }
    if (!preg_match('/^Bearer +([a-fA-F0-9]{64})$/D', trim($authorization), $matches)) {
        header('WWW-Authenticate: Bearer realm="GearDesk"');
        fail(401, 'Please log in and send your Bearer token.');
    }
    $hash = hash('sha256', $matches[1]);
    $statement = $db->prepare('SELECT u.id, u.name, u.email FROM auth_tokens t JOIN users u ON u.id = t.user_id WHERE t.token_hash = :token_hash AND t.expires_at > UTC_TIMESTAMP()');
    $statement->execute(['token_hash' => $hash]);
    $user = $statement->fetch();
    if ($user === false) {
        header('WWW-Authenticate: Bearer realm="GearDesk", error="invalid_token"');
        fail(401, 'Your session is invalid or expired. Please log in again.');
    }
    return ['user' => publicUser($user), 'token_hash' => $hash];
}
