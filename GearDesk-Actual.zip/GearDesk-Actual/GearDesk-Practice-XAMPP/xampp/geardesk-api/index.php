<?php
// GearDesk authentication practice API. PHP 8.x with pdo_mysql; no Composer required.
declare(strict_types=1);
ini_set('display_errors', '0');
require_once __DIR__ . '/config.php';

function respond(int $status, array $body): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}

function fail(int $status, string $message, array $errors = []): void
{
    $body = ['message' => $message];
    if ($errors !== []) {
        $body['errors'] = $errors;
    }
    respond($status, $body);
}

function parameter(string $name, ?string $default = null): ?string
{
    if (!array_key_exists($name, $_GET)) {
        return $default;
    }
    if (!is_string($_GET[$name])) {
        fail(400, 'Query parameters must be single values.');
    }
    return $_GET[$name];
}

function positiveQuery(string $name, ?int $default = null, int $maximum = 2147483647): int
{
    $raw = parameter($name);
    if ($raw === null && $default !== null) {
        return $default;
    }
    $value = filter_var($raw, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => $maximum]]);
    if ($value === false || $value === null) {
        fail(400, $name . ' must be a positive integer within its allowed range.');
    }
    return (int) $value;
}

function jsonBody(): array
{
    $contentType = strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0]));
    if ($contentType !== 'application/json') {
        fail(415, 'Send Content-Type: application/json.');
    }
    try {
        $decoded = json_decode(file_get_contents('php://input'), false, 512, JSON_THROW_ON_ERROR);
    } catch (JsonException $error) {
        fail(400, 'Request body must contain valid JSON.');
    }
    if (!is_object($decoded)) {
        fail(400, 'Request body must be a JSON object.');
    }
    return (array) $decoded;
}

function mapEquipment(array $row): array
{
    return [
        'id' => (int) $row['id'],
        'name' => $row['name'],
        'category_id' => (int) $row['category_id'],
        'category_name' => $row['category_name'],
        'daily_rate' => (float) $row['daily_rate'],
        'available_units' => (int) $row['available_units'],
    ];
}

function findEquipment(PDO $db, int $id): ?array
{
    $statement = $db->prepare('SELECT e.*, c.name AS category_name FROM equipment e JOIN categories c ON c.id = e.category_id WHERE e.id = :id');
    $statement->execute(['id' => $id]);
    $row = $statement->fetch();
    return $row === false ? null : mapEquipment($row);
}

function validateEquipment(PDO $db, array $body, bool $partial): array
{
    $allowed = ['name', 'category_id', 'daily_rate', 'available_units'];
    $errors = [];
    $clean = [];
    foreach (array_keys($body) as $field) {
        if (!in_array($field, $allowed, true)) {
            $errors[$field] = 'This field is not writable. Do not send id or category_name.';
        }
    }
    if ($partial && $body === []) {
        $errors['body'] = 'Supply at least one editable field.';
    }
    foreach ($allowed as $field) {
        if (!array_key_exists($field, $body)) {
            if (!$partial) {
                $errors[$field] = 'This field is required.';
            }
            continue;
        }
        $value = $body[$field];
        if ($field === 'name') {
            $length = is_string($value) ? preg_match_all('/./us', trim($value)) : 0;
            if (!is_string($value) || trim($value) === '' || $length > 80) {
                $errors[$field] = 'Enter a name of 1 to 80 characters.';
            } else {
                $clean[$field] = trim($value);
            }
        } elseif ($field === 'daily_rate') {
            if ((!is_int($value) && !is_float($value)) || !is_finite((float) $value)
                || $value <= 0 || $value > 999999.99 || abs(round($value * 100) - $value * 100) > 0.00001) {
                $errors[$field] = 'Enter a number greater than 0, up to 999999.99, with at most 2 decimal places.';
            } else {
                $clean[$field] = round((float) $value, 2);
            }
        } elseif ($field === 'available_units') {
            if (!is_int($value) || $value < 0 || $value > 9999) {
                $errors[$field] = 'Enter a whole number from 0 to 9999.';
            } else {
                $clean[$field] = $value;
            }
        } else {
            if (!is_int($value) || $value < 1) {
                $errors[$field] = 'Select a valid category using its numeric id.';
            } else {
                $statement = $db->prepare('SELECT id FROM categories WHERE id = :id');
                $statement->execute(['id' => $value]);
                if ($statement->fetch() === false) {
                    $errors[$field] = 'The selected category does not exist.';
                } else {
                    $clean[$field] = $value;
                }
            }
        }
    }
    if ($errors !== []) {
        fail(422, 'Please check the form fields.', $errors);
    }
    return $clean;
}

require_once __DIR__ . '/auth.php';

try {
    $config = configuration();
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $allowedOrigins = array_map('trim', explode(',', $config['ALLOWED_ORIGINS'] ?? ''));
    if ($origin !== '') {
        if (!in_array($origin, $allowedOrigins, true)) {
            fail(403, 'Frontend origin is not allowed. Check backend ALLOWED_ORIGINS.');
        }
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Vary: Origin');
        header('Access-Control-Allow-Methods: GET, POST, PATCH, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Accept, Authorization');
        header('Access-Control-Expose-Headers: WWW-Authenticate');
    }
    $method = $_SERVER['REQUEST_METHOD'];
    if ($method === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
    $resource = parameter('resource', 'health');
    $methods = ['health' => ['GET'], 'register' => ['POST'], 'login' => ['POST'],
        'me' => ['GET'], 'logout' => ['POST'], 'categories' => ['GET'],
        'equipment' => ['GET', 'POST', 'PATCH', 'DELETE']];
    if (!array_key_exists($resource, $methods)) {
        fail(404, 'Resource not found.');
    }
    $allowedMethods = $methods[$resource];
    if (!in_array($method, $allowedMethods, true)) {
        header('Allow: ' . implode(', ', $allowedMethods));
        fail(405, 'Method not allowed for this resource.');
    }
    try {
        $db = database($config);
        $db->query('SELECT COUNT(*) FROM categories');
        $db->query('SELECT COUNT(*) FROM equipment');
        $db->query('SELECT COUNT(*) FROM users');
        $db->query('SELECT COUNT(*) FROM auth_tokens');
    } catch (PDOException $error) {
        error_log('GearDesk database check failed: ' . $error->getMessage());
        fail(503, 'Database unavailable. Start MySQL, import database/geardesk.sql, and check the backend .env.');
    }
    if ($resource === 'health') {
        respond(200, ['message' => 'GearDesk authentication API is ready.', 'database' => 'connected', 'authentication' => 'bearer']);
    }
    if ($resource === 'register') {
        registerUser($db);
    }
    if ($resource === 'login') {
        loginUser($db, $config);
    }
    $session = requireAuthenticated($db);
    if ($resource === 'me') {
        respond(200, ['data' => $session['user']]);
    }
    if ($resource === 'logout') {
        $statement = $db->prepare('DELETE FROM auth_tokens WHERE token_hash = :token_hash');
        $statement->execute(['token_hash' => $session['token_hash']]);
        respond(200, ['message' => 'Logged out.']);
    }
    if ($resource === 'categories') {
        $rows = $db->query('SELECT id, name FROM categories ORDER BY id')->fetchAll();
        $rows = array_map(function (array $row): array {
            return ['id' => (int) $row['id'], 'name' => $row['name']];
        }, $rows);
        respond(200, ['data' => $rows]);
    }
    $id = parameter('id') !== null ? positiveQuery('id') : null;
    if ($method === 'GET' && $id !== null) {
        $item = findEquipment($db, $id);
        if ($item === null) {
            fail(404, 'Equipment not found.');
        }
        respond(200, ['data' => $item]);
    }
    if ($method === 'GET') {
        $page = positiveQuery('page', 1, 1000000);
        $perPage = positiveQuery('per_page', 5, 50);
        $search = trim(parameter('search', ''));
        $categoryId = parameter('category_id') !== null ? positiveQuery('category_id') : null;
        $where = [];
        $parameters = [];
        if ($search !== '') {
            // LOCATE treats search text literally, including SQL wildcard characters.
            $where[] = 'LOCATE(:search, e.name) > 0';
            $parameters['search'] = $search;
        }
        if ($categoryId !== null) {
            $where[] = 'e.category_id = :category_id';
            $parameters['category_id'] = $categoryId;
        }
        $condition = $where === [] ? '' : ' WHERE ' . implode(' AND ', $where);
        $count = $db->prepare('SELECT COUNT(*) FROM equipment e' . $condition);
        $count->execute($parameters);
        $total = (int) $count->fetchColumn();
        $statement = $db->prepare('SELECT e.*, c.name AS category_name FROM equipment e JOIN categories c ON c.id = e.category_id'
            . $condition . ' ORDER BY e.id ASC LIMIT :limit OFFSET :offset');
        foreach ($parameters as $key => $value) {
            $statement->bindValue(':' . $key, $value, is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR);
        }
        $statement->bindValue(':limit', $perPage, PDO::PARAM_INT);
        $statement->bindValue(':offset', ($page - 1) * $perPage, PDO::PARAM_INT);
        $statement->execute();
        respond(200, ['data' => array_map('mapEquipment', $statement->fetchAll()), 'meta' => [
            'page' => $page, 'per_page' => $perPage, 'total' => $total,
            'total_pages' => (int) ceil($total / $perPage),
        ]]);
    }
    if ($method === 'POST') {
        if ($id !== null) {
            fail(400, 'Create records without an id query parameter.');
        }
        $clean = validateEquipment($db, jsonBody(), false);
        $statement = $db->prepare('INSERT INTO equipment (name, category_id, daily_rate, available_units) VALUES (:name, :category_id, :daily_rate, :available_units)');
        $statement->execute($clean);
        $created = findEquipment($db, (int) $db->lastInsertId());
        respond(201, ['message' => 'Equipment created.', 'data' => $created]);
    }
    if ($id === null) {
        fail(400, 'An id query parameter is required for update or delete.');
    }
    if (findEquipment($db, $id) === null) {
        fail(404, 'Equipment not found.');
    }
    if ($method === 'PATCH') {
        $clean = validateEquipment($db, jsonBody(), true);
        $assignments = [];
        foreach (array_keys($clean) as $field) {
            $assignments[] = $field . ' = :' . $field;
        }
        $clean['id'] = $id;
        $statement = $db->prepare('UPDATE equipment SET ' . implode(', ', $assignments) . ' WHERE id = :id');
        $statement->execute($clean);
        respond(200, ['message' => 'Equipment updated.', 'data' => findEquipment($db, $id)]);
    }
    $statement = $db->prepare('DELETE FROM equipment WHERE id = :id');
    $statement->execute(['id' => $id]);
    http_response_code(204);
    exit;
} catch (Throwable $error) {
    error_log('GearDesk API error: ' . $error->getMessage());
    fail(500, 'API setup or server error. Check backend .env and the Apache error log.');
}
