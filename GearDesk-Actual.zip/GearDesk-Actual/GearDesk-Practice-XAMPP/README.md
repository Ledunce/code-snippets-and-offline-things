# GearDesk - Authentication Practice Assessment

Revised Set B: registration, login, Bearer-token API consumption, logout, and inventory CRUD.
Original training exercise, not an official TESDA paper. The actual assessment's API may differ.

**Start here:** configure the backend below, then follow `LEARN-AUTH-FIRST.md` before the timer.
Build the frontend yourself in Vue; the mockups are visual references.

## Where is the backend?

**`xampp/geardesk-api/`** contains `index.php`, `auth.php`, `config.php`, `.env`, and `.htaccess`.
**`database/geardesk.sql`** is the importable database. These are also in the smaller
`GearDesk-Backend-Auth.zip` download.

## XAMPP setup on Windows

1. Extract the ZIP. Start **Apache** and **MySQL** in XAMPP Control Panel.
2. Copy `xampp\geardesk-api` into `C:\xampp\htdocs\` (or your installation's `htdocs`).
   The final path must be `C:\xampp\htdocs\geardesk-api\index.php`.
   If the old practice folder exists, keep a backup and replace its files with this version.
3. Visit `http://localhost/phpmyadmin/`. Choose **Import**, select `database\geardesk.sql`, click **Go**.
   It creates the separate **`geardesk_auth_practice`** database with four tables.
   It does not drop the old database. Re-importing does not reset edits or accounts.
4. Open the copied backend `.env`. Local defaults:

   ```env
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=geardesk_auth_practice
   DB_USERNAME=root
   DB_PASSWORD=""
   TOKEN_TTL_MINUTES=60
   ```

   Use your MySQL password if one is set. Keep the supplied `ALLOWED_ORIGINS` line.
   These database credentials are different from the email/password entered into the app.
5. Open `http://localhost/geardesk-api/index.php?resource=health`.
   Expect `"database":"connected"` and `"authentication":"bearer"`.
6. Open `http://localhost/geardesk-api/index.php?resource=equipment`.
   **401 is expected before login.** An address-bar visit does not send a Bearer token.
7. Follow `LEARN-AUTH-FIRST.md` to register, log in, and make an authenticated GET.
8. In a separate Vue/Vite project, copy `frontend.env.example` to `.env.local`:

   ```env
   VITE_API_BASE_URL=http://localhost/geardesk-api/index.php
   ```

   Restart Vite after environment changes. Keep Apache and MySQL running.

PHP 8.x with pdo_mysql is required. No Composer, PHP framework, rewriting, or mail service is needed.
There are 17 equipment records, four categories, and initially no users. Register your own fictional account.

## Included materials

| File / folder | Purpose |
| --- | --- |
| `Practice-Assessment.pdf` | Printable requirements, mockups, timing, rubric |
| `CLIENT-REQUIREMENTS.md` | Full candidate brief |
| `API-DOCUMENTATION.md` | Exact routes, JSON, statuses, and token rules |
| `LEARN-AUTH-FIRST.md` | Guided steps and small Vue authentication examples |
| `xampp/geardesk-api/` | PHP backend and local configuration |
| `database/geardesk.sql` | MariaDB/MySQL import |
| `mockups/Mockup-View.html` | Offline Login/Register/inventory/dialog reference viewer |
| `mockups/*.png` | Individual desktop and mobile mockups |
| `frontend.env.example` | Public frontend API URL |
| `verify-api.ps1` | Optional auth/CRUD/logout backend smoke check |
| `MANUAL-TESTS.csv` | Frontend acceptance sheet to complete |
| `VERIFICATION.md` | Checks performed and limitations |

## Ports and CORS

For Apache on 8080, use `http://localhost:8080/` in all API and phpMyAdmin URLs.
MySQL's port is separate and belongs in backend DB_PORT.
The backend allows localhost/127.0.0.1 origins on 5173, 5174, and 4173.
Add your exact frontend origin to ALLOWED_ORIGINS if needed.
Authorization is already allowed for CORS preflight. Do not use `mode: "no-cors"`.

## Optional backend check

In PowerShell, if your session permits script execution:

```powershell
.\verify-api.ps1
# Another Apache port:
.\verify-api.ps1 -ApiUrl 'http://localhost:8080/geardesk-api/index.php'
```

The script registers a unique fictional account, tests login/protected CRUD, deletes its temporary
equipment, and logs out. The practice account remains. It does not print the access token.

PHP syntax checks with default XAMPP:

```powershell
Get-ChildItem .\xampp\geardesk-api\*.php | ForEach-Object { & 'C:\xampp\php\php.exe' -l $_.FullName }
```

## Troubleshooting

| Symptom | Check |
| --- | --- |
| Cannot connect | Apache running; correct Apache port |
| HTML / 404 | Correct folder path and URL ending in index.php |
| 503 | MySQL running, new SQL imported, backend .env correct |
| Health does not mention bearer | Old PHP files are still running |
| Register 409 | Email already exists; log in or use a new practice email |
| Login 401 | Incorrect email or password |
| Inventory 401 | Missing/expired/revoked token; obtain a new one and attach it |
| CORS error | Exact frontend origin in ALLOWED_ORIGINS |
| 415 | Send Content-Type: application/json for JSON bodies |
| 422 | Read errors; field names and numeric types must match the API docs |
| DELETE succeeds then JS errors | 204 has no body; do not parse JSON |
| Added record missing | Results sort by ascending ID; navigate to the last page |

All registered users share this practice inventory. No roles, refresh tokens, email verification,
or password reset tasks are included. This is a local learning backend; use fictional accounts and
dedicated practice passwords. Hosted Bearer-token APIs require HTTPS to protect tokens in transit.

References: https://www.rfc-editor.org/rfc/rfc6750.html
and https://www.php.net/manual/en/book.password.php
