-- GearDesk practice database for XAMPP MariaDB / MySQL.
-- Import once through phpMyAdmin > Import. No existing database is dropped.
CREATE DATABASE IF NOT EXISTS geardesk_auth_practice CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE geardesk_auth_practice;

CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL,
    email VARCHAR(190) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY unique_user_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS auth_tokens (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id INT UNSIGNED NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY unique_token_hash (token_hash),
    KEY token_user (user_id),
    CONSTRAINT fk_token_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS categories (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(60) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY unique_category_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS equipment (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT,
    name VARCHAR(80) NOT NULL,
    category_id INT UNSIGNED NOT NULL,
    daily_rate DECIMAL(8,2) UNSIGNED NOT NULL,
    available_units SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    PRIMARY KEY (id),
    KEY equipment_category (category_id),
    CONSTRAINT fk_equipment_category FOREIGN KEY (category_id) REFERENCES categories (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO categories (id, name) VALUES
(1, 'Audio'), (2, 'Lighting'), (3, 'Presentation'), (4, 'Power');

INSERT IGNORE INTO equipment (id, name, category_id, daily_rate, available_units) VALUES
(1, 'Portable PA Speaker', 1, 850.00, 6),
(2, 'Wireless Microphone', 1, 350.00, 12),
(3, 'LED Par Light', 2, 250.00, 16),
(4, 'HD Projector', 3, 1200.00, 0),
(5, 'Extension Cable 20m', 4, 100.00, 10),
(6, 'Audio Mixer 8-channel', 1, 750.00, 4),
(7, 'Lapel Microphone', 1, 300.00, 8),
(8, 'Moving Head Light', 2, 900.00, 5),
(9, 'Softbox Light', 2, 400.00, 6),
(10, 'Projector Screen', 3, 450.00, 7),
(11, 'Presentation Clicker', 3, 150.00, 14),
(12, 'Cable Reel 30m', 4, 180.00, 5),
(13, 'Surge Protector', 4, 120.00, 15),
(14, 'Speaker Stand', 1, 150.00, 9),
(15, 'LED Light Bar', 2, 350.00, 0),
(16, 'Portable Monitor', 3, 650.00, 3),
(17, 'UPS Backup Unit', 4, 500.00, 2);
