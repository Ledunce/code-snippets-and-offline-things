# Verification - revised authentication package

## Completed here

- Static checks verified 17 unique equipment IDs, four categories, valid category references,
  pagination sizes 5/5/5/2, and documented fresh-data search/filter fixtures.
- SQL and backend configuration both use the separate geardesk_auth_practice database.
- Source review checked route names, documented response fields, the authentication gate before
  category/equipment handlers, preflight before authentication, and CORS permission for Authorization.
- Source review checked password_hash/password_verify, random token creation, hashed token storage,
  expiry checking, and server-side logout revocation. This is source inspection, not execution.
- All 12 JSON examples parsed; all seven JavaScript learning fragments passed Node syntax checks.
- The offline reference viewer's JavaScript passed Node syntax checking. It embeds all nine screens
  and has no external network requests. Its controls were not exercised in a browser here.
- All ten PNGs decoded. The desktop auth/inventory overview and mobile registration were visually inspected.
- All eight PDF pages were rendered; the contact sheet and detailed contract/rubric pages were reviewed.
- The frontend manual test sheet contains 45 distinct cases, including authentication and session cleanup.
- Both download archives were checked for ZIP integrity and required PHP, environment, and SQL files.

## Runtime verification remaining

PHP, MySQL/MariaDB, Apache and PowerShell are not available here. PHP lint, a real MariaDB import,
live endpoint behavior, expiry/revocation execution, browser CORS against XAMPP, and the PowerShell
smoke script have not been run here. No passed live XAMPP integration test is claimed.

## Run before the timed attempt

1. Start XAMPP, import database/geardesk.sql, and configure the backend .env using README.md.
2. Confirm health reports connected/bearer. An equipment URL without a token should return 401.
3. Run the included PHP lint command and, if your session permits, verify-api.ps1.
4. The smoke script checks registration, duplicate email, wrong password, valid/invalid tokens,
   protected CRUD, validation, empty search, empty 204 delete, logout, and old-token rejection.
5. Test expiry manually as described in API-DOCUMENTATION.md.
6. Build your Vue frontend and complete MANUAL-TESTS.csv, including mobile and API-outage cases.

The smoke script registers one fictional account, creates/updates/deletes its own equipment,
and logs out. It leaves the practice account and can advance equipment auto-increment IDs.
It does not reset or delete supplied seed records. Do not assume IDs are consecutive.
