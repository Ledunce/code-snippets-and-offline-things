# Practice Front-End Assessment - GearDesk, Revised Set B

Original training exercise, not an official TESDA assessment paper or prediction of exact tasks.

## Client brief

GearDesk rents equipment for meetings and events. Staff need to register an account, log in, and
manage a shared inventory. The client supplies a PHP API and MariaDB/MySQL database for XAMPP.
Build the Vue frontend from the provided mockups.

Duration: **5.5 hours** for this rehearsal: 30 minutes preparation, five hours implementation.
First use LEARN-AUTH-FIRST.md for an untimed learning exercise.

## Registration

- Name, email, password, confirm password; link to Login.
- Validate required fields, email format, password length, and matching confirmation.
- POST documented JSON to register. Show 422 field errors and 409 duplicate-email errors.
- On 201, show success and switch to Login. This API does not auto-login.
- Do not store passwords in browser storage or Git.

## Login and session

- Email and password fields; link to Register. POST to login.
- On 200, read data.access_token and data.user.
- Store token in Vue state and, for this local exercise, sessionStorage to survive reloads.
- Send Authorization: Bearer <token> on every protected request.
- Verify any saved token with GET me before revealing inventory after reload.
- On protected-request 401, clear session/private data and show Login.
- On a network/server failure, show Retry; do not assume the token is invalid.
- Show the current user's name and Logout in the signed-in header; do not display raw tokens.
- POST Logout, clear state/storage on success or invalid-token 401, then show Login.
- Hide inventory while signed out. The supplied backend also enforces authentication.

## Inventory

- Load equipment and categories after successful login/session verification.
- Show name, category, daily rate in pesos (two decimals), available units, status, Edit/Delete.
- Status: zero units = Out of stock; otherwise Available.
- Add/Edit all four fields in modals. Category options must come from the API.
- Confirm deletion by naming the selected equipment. Cancel preserves the record.
- Close save modals only on success. Preserve ordinary inputs after failed requests.
- Use server-side pagination, five items/page, totals from meta, correct boundary buttons.
- Search by name and filter by category; Apply resets page to 1, Clear resets both filters.
- Re-fetch a valid preceding page if deletion empties the last page.
- Handle loading, empty data, no matches, errors, Retry, and empty 204 delete responses.
- Prevent repeated submissions while pending.

Validation: trimmed name 1-80 characters; valid numeric category ID; numeric daily rate > 0 and
<= 999999.99, at most two decimals; integer available units 0-9999. Zero units is valid.

## UI and accessibility

- Follow Login/Register/inventory/dialog mockups; use mobile cards at 375px and 320px.
- Teal primary actions, navy text, pale background, consistent spacing and hierarchy.
- Labeled fields, visible keyboard focus, useful form/status messages, proper button types.
- Keep keyboard focus in the active modal; Escape/Cancel closes idle dialogs; return focus afterward.
- Place one modal of each type outside record loops.
- Render user input as text with interpolation, not v-html.
- Keep token strings and database configuration out of normal user flows.

## Suggested schedule

| Period | Target |
| --- | --- |
| Preparation: 30 min | Configure backend, import SQL, health check, docs, frontend dependencies |
| 0:00-0:55 | Register/Login, token handling, protected GET, Logout |
| 0:55-1:40 | Inventory layout, categories, loading/error/empty states |
| 1:40-2:40 | Add/Edit, validation, authenticated POST/PATCH |
| 2:40-3:05 | Delete confirmation and authenticated DELETE |
| 3:05-3:45 | Server pagination, search, category filter |
| 3:45-4:35 | Responsive/session/persistence/failure checks |
| 4:35-5:00 | Fixes, README, tests, Git, build |

## Submission and practice rubric

Submit Vue source, dependency manifest/lockfile, public API .env.example, README, a short plan,
completed test sheet, and meaningful Git commits. Exclude node_modules, tokens, and private
backend credentials. The frontend build must succeed.

| Area | Points |
| --- | ---: |
| Registration and login | 20 |
| Token use, session verification, 401 handling, logout | 15 |
| Inventory CRUD and categories | 25 |
| Server pagination, search, category filter | 15 |
| Responsive mockup matching and accessibility | 10 |
| Validation, failures, pending/loading/empty states | 10 |
| Documentation, test evidence, Git, build | 5 |
| Total | 100 |

Practice target: 80/100 with registration, login, protected requests, CRUD, and pagination working.
This is a training target, not TESDA's official competency decision.
