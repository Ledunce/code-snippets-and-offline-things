param([string]$ApiUrl = 'http://localhost/geardesk-api/index.php')

$ErrorActionPreference = 'Stop'
$checks = [System.Collections.Generic.List[object]]::new()
$authHeaders = @{}
$createdId = $null
$loggedIn = $false

function Confirm-Check([bool]$Condition, [string]$Name) {
    if (-not $Condition) { throw "FAILED: $Name" }
    $checks.Add([PSCustomObject]@{ Check = $Name; Result = 'PASS' })
}

function Confirm-Status([string]$Uri, [string]$Method, [hashtable]$Headers, [object]$Payload, [int]$Expected, [string]$Name) {
    $params = @{ Uri = $Uri; Method = $Method; Headers = $Headers }
    if ($null -ne $Payload) {
        $params.ContentType = 'application/json'
        $params.Body = $Payload | ConvertTo-Json -Compress
    }
    $received = 0
    try { Invoke-RestMethod @params | Out-Null }
    catch {
        if ($_.Exception.Response) { $received = [int]$_.Exception.Response.StatusCode }
        else { throw }
    }
    Confirm-Check ($received -eq $Expected) $Name
}

try {
    $health = Invoke-RestMethod -Uri ($ApiUrl + '?resource=health')
    Confirm-Check ($health.database -eq 'connected' -and $health.authentication -eq 'bearer') 'Authentication backend health'
    Confirm-Status ($ApiUrl + '?resource=equipment') 'Get' @{} $null 401 'Protect equipment before login'
    Confirm-Status ($ApiUrl + '?resource=categories') 'Get' @{} $null 401 'Protect categories before login'
    Confirm-Status ($ApiUrl + '?resource=me') 'Get' @{} $null 401 'Protect current user before login'

    $email = 'smoke-' + [guid]::NewGuid().ToString('N') + '@example.test'
    $account = @{ name = 'API Practice Staff'; email = $email; password = 'Practice123!'; password_confirmation = 'Practice123!' }
    $badAccount = @{ name = 'API Practice Staff'; email = $email; password = 'Practice123!'; password_confirmation = 'Different123!' }
    Confirm-Status ($ApiUrl + '?resource=register') 'Post' @{} $badAccount 422 'Reject mismatched confirmation'
    $registered = Invoke-RestMethod -Uri ($ApiUrl + '?resource=register') -Method Post -ContentType 'application/json' -Body ($account | ConvertTo-Json -Compress)
    Confirm-Check ($registered.data.email -eq $email -and $null -eq $registered.data.access_token) 'Register without automatic login'
    Confirm-Status ($ApiUrl + '?resource=register') 'Post' @{} $account 409 'Reject duplicate email'
    Confirm-Status ($ApiUrl + '?resource=login') 'Post' @{} @{ email = $email; password = 'Wrong123!' } 401 'Reject wrong login password'

    $credentials = @{ email = $email; password = 'Practice123!' }
    $login = Invoke-RestMethod -Uri ($ApiUrl + '?resource=login') -Method Post -ContentType 'application/json' -Body ($credentials | ConvertTo-Json -Compress)
    Confirm-Check ($login.data.token_type -eq 'Bearer' -and $login.data.access_token.Length -eq 64 -and $login.data.expires_in -gt 0) 'Login returns Bearer token and expiry'
    $authHeaders = @{ Authorization = 'Bearer ' + $login.data.access_token }
    $loggedIn = $true
    $me = Invoke-RestMethod -Uri ($ApiUrl + '?resource=me') -Headers $authHeaders
    Confirm-Check ($me.data.email -eq $email) 'Token identifies current user'
    Confirm-Status ($ApiUrl + '?resource=me') 'Get' @{ Authorization = 'Bearer ' + ('0' * 64) } $null 401 'Reject invalid token'

    $categories = Invoke-RestMethod -Uri ($ApiUrl + '?resource=categories') -Headers $authHeaders
    Confirm-Check (@($categories.data).Count -eq 4) 'Four authenticated categories'
    $first = Invoke-RestMethod -Uri ($ApiUrl + '?resource=equipment&page=1&per_page=5') -Headers $authHeaders
    Confirm-Check ($first.meta.page -eq 1 -and $first.meta.per_page -eq 5 -and @($first.data).Count -eq [Math]::Min(5, $first.meta.total)) 'Server pagination'
    $empty = Invoke-RestMethod -Uri ($ApiUrl + '?resource=equipment&search=__no_match_geardesk_987654__') -Headers $authHeaders
    Confirm-Check (@($empty.data).Count -eq 0 -and $empty.meta.total -eq 0 -and $empty.meta.total_pages -eq 0) 'Empty search metadata'

    $payload = @{ name = 'Temporary API smoke equipment'; category_id = 1; daily_rate = 199.50; available_units = 0 }
    Confirm-Status ($ApiUrl + '?resource=equipment') 'Post' @{} $payload 401 'Protect create before login'
    $created = Invoke-RestMethod -Uri ($ApiUrl + '?resource=equipment') -Method Post -Headers $authHeaders -ContentType 'application/json' -Body ($payload | ConvertTo-Json -Compress)
    $createdId = $created.data.id
    Confirm-Check ($null -ne $createdId -and $created.data.available_units -eq 0) 'Authenticated create accepts zero units'
    $update = @{ name = 'Updated API smoke equipment'; category_id = 2; daily_rate = 225.75; available_units = 3 }
    $updated = Invoke-RestMethod -Uri ($ApiUrl + '?resource=equipment&id=' + $createdId) -Method Patch -Headers $authHeaders -ContentType 'application/json' -Body ($update | ConvertTo-Json -Compress)
    Confirm-Check ($updated.data.name -eq $update.name -and $updated.data.category_name -eq 'Lighting' -and $updated.data.daily_rate -eq 225.75 -and $updated.data.available_units -eq 3) 'Authenticated update changes all fields'
    Confirm-Status ($ApiUrl + '?resource=equipment&id=' + $createdId) 'Patch' @{} $update 401 'Protect update before login'
    Confirm-Status ($ApiUrl + '?resource=equipment&id=' + $createdId) 'Delete' @{} $null 401 'Protect delete before login'
    Confirm-Status ($ApiUrl + '?resource=equipment') 'Post' $authHeaders @{ name = ' '; category_id = 1; daily_rate = 100; available_units = 1 } 422 'Reject blank equipment name'
    Confirm-Status ($ApiUrl + '?resource=equipment') 'Post' $authHeaders @{ name = 'Invalid units'; category_id = 1; daily_rate = 100; available_units = 1.5 } 422 'Reject fractional units'
    Confirm-Status ($ApiUrl + '?resource=equipment') 'Post' $authHeaders @{ name = 'Invalid category'; category_id = 99999; daily_rate = 100; available_units = 1 } 422 'Reject unknown category'

    $deleted = Invoke-WebRequest -UseBasicParsing -Uri ($ApiUrl + '?resource=equipment&id=' + $createdId) -Method Delete -Headers $authHeaders
    Confirm-Check ([int]$deleted.StatusCode -eq 204 -and [string]::IsNullOrEmpty([string]$deleted.Content)) 'Delete returns empty 204'
    $deletedId = $createdId
    $createdId = $null
    Confirm-Status ($ApiUrl + '?resource=equipment&id=' + $deletedId) 'Get' $authHeaders $null 404 'Deletion persists'

    $logout = Invoke-RestMethod -Uri ($ApiUrl + '?resource=logout') -Method Post -Headers $authHeaders
    $loggedIn = $false
    Confirm-Check ($logout.message -eq 'Logged out.') 'Logout succeeds'
    Confirm-Status ($ApiUrl + '?resource=me') 'Get' $authHeaders $null 401 'Revoked token cannot identify user'
    Confirm-Status ($ApiUrl + '?resource=equipment') 'Get' $authHeaders $null 401 'Revoked token cannot read inventory'

    $checks | Format-Table -AutoSize
    Write-Host ('Passed ' + $checks.Count + ' backend checks. Frontend acceptance tests remain separate.')
    Write-Host ('A fictional practice account remains: ' + $email)
} finally {
    if ($null -ne $createdId -and $loggedIn) {
        try { Invoke-RestMethod -Uri ($ApiUrl + '?resource=equipment&id=' + $createdId) -Method Delete -Headers $authHeaders | Out-Null }
        catch { Write-Warning ('Delete temporary equipment ' + $createdId + ' manually.') }
    }
    if ($loggedIn) {
        try { Invoke-RestMethod -Uri ($ApiUrl + '?resource=logout') -Method Post -Headers $authHeaders | Out-Null }
        catch { Write-Warning 'Logout cleanup failed; the test token will expire automatically.' }
    }
}
