# Learn authentication first

You already send GET, POST, PATCH, and DELETE. Authentication adds a login request and one
header to later requests. Practise these steps before starting the timed exercise.

## Three different credentials

| Value | Used by | Purpose |
| --- | --- | --- |
| MySQL username/password | PHP backend .env | Connect PHP to the database |
| Registered email/password | Login form | Ask the API to verify the user |
| Returned access token | Later fetch requests | Prove the request belongs to a signed-in session |

The backend generates the token. Do not invent one or use a database password as a token.
Bearer means possession of the token grants its access. Keep it out of URLs.

## 1. Try without a token

After README setup, open `http://localhost/geardesk-api/index.php?resource=equipment`.
401 is expected: an address-bar visit sends no Authorization header.

## 2. Register a fictional account

First learn the request using a fixed payload; then replace the values with your form refs:

```js
const API_URL = import.meta.env.VITE_API_BASE_URL;

async function registerPracticeAccount() {
  const response = await fetch(`${API_URL}?resource=register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Practice Staff",
      email: "staff@example.test",
      password: "Practice123!",
      password_confirmation: "Practice123!"
    })
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.message);
  return result; // 201: account created, but no token yet
}
```

Call from an async event handler with try/catch and show errors in a status ref.
Run once: repeating the email returns 409. Registration is not required each time the app starts.

## 3. Log in and keep the token

In script setup (declare API_URL once, as above):

```js
import { ref } from "vue";

const token = ref("");
const currentUser = ref(null);
const email = ref("");
const password = ref("");
const statusMessage = ref("");
const saving = ref(false);

async function login() {
  if (saving.value) return;
  saving.value = true;
  statusMessage.value = "";
  try {
    const response = await fetch(`${API_URL}?resource=login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: email.value.trim(),
        password: password.value
      })
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.message);

    token.value = result.data.access_token;
    currentUser.value = result.data.user;
    password.value = "";
    statusMessage.value = "Logged in.";
    // Next call your authenticated getEquipment().
  } catch (error) {
    statusMessage.value = error.message || "Unable to log in.";
  } finally {
    saving.value = false;
  }
}
```

The connection: response JSON -> result.data.access_token -> token.value.
Do not trim passwords: spaces may be intentional. Never save passwords in browser storage.
Try a wrong password, then the correct one. Only success should reveal inventory.

## 4. Attach the token to a familiar GET

```js
const equipment = ref([]);

async function getEquipment() {
  try {
    const response = await fetch(
      `${API_URL}?resource=equipment&page=1&per_page=5`,
      { headers: { Authorization: `Bearer ${token.value}` } }
    );
    const result = await response.json();
    if (response.status === 401) {
      token.value = "";
      currentUser.value = null;
      equipment.value = [];
      sessionStorage.removeItem("geardesk_token");
      statusMessage.value = "Please log in again.";
      return;
    }
    if (!response.ok) throw new Error(result.message);
    equipment.value = result.data;
    // Pagination information is result.meta.
  } catch (error) {
    statusMessage.value = error.message || "Unable to load equipment.";
  }
}
```

The new part is the Authorization header. Bearer is a fixed word; the value after it is the token
from Login. Add the same header on categories, me, POST, PATCH, and DELETE.
POST/PATCH need both headers:

```js
headers: {
  "Content-Type": "application/json",
  Authorization: `Bearer ${token.value}`
}
```

Inspect Login's JSON and the equipment request header in DevTools > Network. Do not commit tokens.

## 5. Survive a refresh

For this local exercise use sessionStorage. It survives reloads in the same tab and is accessible
to page JavaScript; do not use it for passwords.

After successful login:

```js
sessionStorage.setItem("geardesk_token", token.value);
```

Replace the earlier empty token declaration with:

```js
const token = ref(sessionStorage.getItem("geardesk_token") || "");
```

In onMounted, if token exists, request GET me with Authorization. On 200 set currentUser from
result.data and load inventory. On 401 clear the session. On network/503 show Retry and keep
the token. Verify before revealing inventory.
Cancel pending loads or ignore results from an old token so a late response cannot restore
private data after Logout.

## 6. Log out on the server

```js
async function logout() {
  if (saving.value) return;
  saving.value = true;
  try {
    const response = await fetch(`${API_URL}?resource=logout`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token.value}` }
    });
    const result = await response.json();
    if (!response.ok && response.status !== 401) {
      throw new Error(result.message);
    }
    token.value = "";
    currentUser.value = null;
    equipment.value = [];
    sessionStorage.removeItem("geardesk_token");
    statusMessage.value = "Logged out.";
  } catch (error) {
    statusMessage.value = error.message || "Logout failed. Try again.";
  } finally {
    saving.value = false;
  }
}
```

Reset categories/open forms and cancel in-flight loads as part of your finished session cleanup.
Removing only a local token does not revoke it on the backend.

## Understanding check

1. Register: 201, no token. Repeat email: 409.
2. Wrong login password: 401. Correct login: token at data.access_token.
3. Equipment without header: 401. With header: 200, data and meta.
4. Add/Edit/Delete with the same header.
5. Refresh and verify saved token using me.
6. Logout, then reuse the old token: 401.
7. Start the full assessment from CLIENT-REQUIREMENTS.md.

These are learning fragments, not a finished frontend. Merge carefully: declare each ref/function
once and use one shared session-cleanup function in your final application.

References: https://www.rfc-editor.org/rfc/rfc6750.html
and https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
