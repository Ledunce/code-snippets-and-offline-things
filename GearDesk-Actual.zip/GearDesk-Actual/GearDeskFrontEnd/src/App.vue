<script setup>
import { ref, computed, onMounted } from "vue";

import Login from "./pages/Login.vue";
import Register from "./pages/Register.vue";
import Landing from "./pages/Landing.vue";
import Equipment from "./pages/Equipment.vue";

import { token, currentUser } from "./auth.js";

const API_URL = import.meta.env.VITE_API_BASE_URL;

const currentPage = ref("landing");
const statusMessage = ref("");

const checkingSession = ref(false);
const sessionCheckFailed = ref(false);
const loggingOut = ref(false);
const sessionVerified = ref(false);

// A saved token must be verified before showing Equipment.
const isLoggedIn = computed(() =>
  sessionVerified.value && Boolean(token.value)
);

// Remove authentication from Vue state and browser storage.
function clearSession() {
  token.value = "";
  currentUser.value = null;
  sessionVerified.value = false;

  sessionStorage.removeItem("geardesk_token");
}

async function verifySession() {
  if (checkingSession.value) return;

  checkingSession.value = true;
  sessionCheckFailed.value = false;
  sessionVerified.value = false;
  statusMessage.value = "";

  try {
    // Use the current token or restore it after a refresh.
    const savedToken =
      token.value || sessionStorage.getItem("geardesk_token");

    if (!savedToken) {
      clearSession();

      if (currentPage.value === "equipment") {
        currentPage.value = "login";
      }

      return;
    }

    token.value = savedToken;

    if (!API_URL) {
      throw new Error(
        "API URL is missing. Check .env.local and restart Vite."
      );
    }

    // Ask the backend whether this token is still valid.
    const response = await fetch(
      API_URL + "?resource=me",
      {
        headers: {
          Authorization: "Bearer " + savedToken
        }
      }
    );

    if (response.status === 401) {
      clearSession();
      currentPage.value = "login";
      statusMessage.value =
        "Your session expired. Please log in again.";
      return;
    }

    const result = await response.json();

    if (!response.ok) {
      throw new Error(
        result.message || "Unable to verify your session."
      );
    }

    // The backend confirmed the user and token.
    currentUser.value = result.data;
    sessionStorage.setItem("geardesk_token", savedToken);

    sessionVerified.value = true;
    currentPage.value = "equipment";
  } catch (error) {
    // Keep the token during a temporary connection failure.
    // The Retry button will attempt verification again.
    sessionCheckFailed.value = true;
    statusMessage.value =
      error.message || "Unable to verify your session.";
  } finally {
    checkingSession.value = false;
  }
}

function openPage(page) {
  if (checkingSession.value || loggingOut.value) return;

  statusMessage.value = "";

  // Protect navigation to Equipment.
  if (page === "equipment" && !isLoggedIn.value) {
    currentPage.value = "login";
    statusMessage.value = "Please log in first.";
    return;
  }

  currentPage.value = page;
}

function registrationFinished() {
  currentPage.value = "login";
  statusMessage.value = "Account created. Please log in.";
}

async function logout() {
  if (loggingOut.value) return;

  // Equipment already clears an expired token before
  // emitting its logout event.
  if (!token.value) {
    clearSession();
    currentPage.value = "login";
    statusMessage.value = "Please log in again.";
    return;
  }

  loggingOut.value = true;
  statusMessage.value = "Logging out...";

  try {
    // Send the token BEFORE removing it locally.
    // This lets the backend revoke the session.
    const response = await fetch(
      API_URL + "?resource=logout",
      {
        method: "POST",
        headers: {
          Authorization: "Bearer " + token.value
        }
      }
    );

    // An already-invalid token can also end the local session.
    if (!response.ok && response.status !== 401) {
      const result = await response.json();

      throw new Error(
        result.message || "Unable to log out."
      );
    }

    clearSession();
    currentPage.value = "login";
    statusMessage.value = "Logged out.";
  } catch (error) {
    // Keep the session so the user can retry Logout.
    statusMessage.value =
      error.message || "Logout failed. Please try again.";
  } finally {
    loggingOut.value = false;
  }
}

// Check for a saved session when the app starts.
onMounted(verifySession);
</script>

<template>
  <!-- Hide navigation while checking or retrying a session. -->
  <nav v-if="!checkingSession && !sessionCheckFailed">
    <button
      type="button"
      :disabled="loggingOut"
      @click="openPage('landing')"
    >
      Home
    </button>

    <template v-if="isLoggedIn">
      <button
        type="button"
        :disabled="loggingOut"
        @click="openPage('equipment')"
      >
        Equipment
      </button>

      <button
        type="button"
        :disabled="loggingOut"
        @click="logout"
      >
        {{ loggingOut ? "Logging out..." : "Log out" }}
      </button>
    </template>

    <template v-else>
      <button
        type="button"
        @click="openPage('register')"
      >
        Register
      </button>

      <button
        type="button"
        @click="openPage('login')"
      >
        Login
      </button>
    </template>
  </nav>

  <!-- App-level messages remain visible across page changes. -->
  <p role="status">{{ statusMessage }}</p>

  <p v-if="checkingSession">
    Checking your session...
  </p>

  <div v-else-if="sessionCheckFailed">
    <button type="button" @click="verifySession">
      Retry connection
    </button>
  </div>

  <template v-else>
    <!-- Login saves the token, then App verifies it. -->
   <Login
  v-if="currentPage === 'login'"
  @logged-in="verifySession"
  @register="openPage('register')"
/>

  <Register
  v-else-if="currentPage === 'register'"
  @registered="registrationFinished"
  @login="openPage('login')"
/>

    <Landing
      v-else-if="currentPage === 'landing'"
    />

    <!-- Guard rendering as well as navigation. -->
    <Equipment
      v-else-if="currentPage === 'equipment' && isLoggedIn"
      @logout="logout"
    />
  </template>
</template>

<style scoped>
nav {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 16px;
}

button {
  padding: 8px 14px;
  cursor: pointer;
}

button:disabled {
  cursor: wait;
}
</style>