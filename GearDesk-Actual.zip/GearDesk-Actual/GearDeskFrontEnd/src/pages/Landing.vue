<script setup>
const emit = defineEmits(["landing"]);

</script>

<template>
    <h1>
        This is a landing page
    </h1>
</template>

<style scoped>
 body {
    background: whitesmoke;
    color:black;
 }
</style>