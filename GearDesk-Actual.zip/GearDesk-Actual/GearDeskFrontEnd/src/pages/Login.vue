<script setup>
import { ref } from "vue";
import { token, currentUser } from "../auth.js";

const API_URL = import.meta.env.VITE_API_BASE_URL;

// App.vue handles navigation after these events.
const emit = defineEmits(["logged-in", "register"]);

const email = ref("");
const password = ref("");

const statusMessage = ref("");
const hasError = ref(false);
const saving = ref(false);

async function login() {
  // Prevent repeated submissions while waiting for the API.
  if (saving.value) return;

  statusMessage.value = "";
  hasError.value = false;

  // Check empty values without changing the password.
  if (!email.value.trim() || !password.value) {
    hasError.value = true;
    statusMessage.value = "Enter your email and password.";
    return;
  }

  saving.value = true;

  try {
    if (!API_URL) {
      throw new Error(
        "API URL is missing. Check .env.local and restart Vite."
      );
    }

    // Login is public, so no Bearer token is needed here.
    const response = await fetch(
      API_URL + "?resource=login",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email: email.value.trim(),
          password: password.value
        })
      }
    );

    const result = await response.json();

    // Handle wrong credentials and other HTTP errors.
    if (!response.ok) {
      throw new Error(
        result.message || "Unable to log in."
      );
    }

    // Confirm the expected login response exists.
    if (
      typeof result.data?.access_token !== "string" ||
      !result.data.access_token ||
      !result.data.user
    ) {
      throw new Error(
        "The login response is missing the token or user."
      );
    }

    // Store the token so App.vue can restore it after refresh.
    sessionStorage.setItem(
      "geardesk_token",
      result.data.access_token
    );

    // Update the shared authentication refs.
    token.value = result.data.access_token;
    currentUser.value = result.data.user;

    password.value = "";
    statusMessage.value = "Logged in.";

    // App.vue now verifies the session and opens Equipment.
    emit("logged-in");
  } catch (error) {
    hasError.value = true;
    statusMessage.value =
      error.message || "Unable to log in. Please try again.";
  } finally {
    // Re-enable the form after success or failure.
    saving.value = false;
  }
}
</script>

<template>
  <section class="login-page">
    <header class="brand">
      <h1>GearDesk</h1>
      <p>Equipment rental workspace</p>
    </header>

    <!-- Submit handles both button clicks and Enter. -->
    <form class="login-form" @submit.prevent="login">
      <h2>Welcome back</h2>
      <p class="subtitle">
        Log in to manage your equipment.
      </p>

      <div class="form-group">
        <label for="login-email">Email address</label>

        <input
          id="login-email"
          v-model="email"
          name="email"
          type="email"
          autocomplete="username"
          placeholder="you@example.com"
          :disabled="saving"
          required
        />
      </div>

      <div class="form-group">
        <label for="login-password">Password</label>

        <input
          id="login-password"
          v-model="password"
          name="password"
          type="password"
          autocomplete="current-password"
          placeholder="Enter your password"
          :disabled="saving"
          required
        />
      </div>

      <!-- Display API and validation messages inside the form. -->
      <p
        v-if="statusMessage"
        class="status-message"
        :class="{ error: hasError }"
        role="status"
      >
        {{ statusMessage }}
      </p>

      <button
        class="submit-button"
        type="submit"
        :disabled="saving"
      >
        {{ saving ? "Logging in..." : "Log in" }}
      </button>

      <p class="register-prompt">
        New to GearDesk?

        <button
          class="text-button"
          type="button"
          :disabled="saving"
          @click="emit('register')"
        >
          Create an account
        </button>
      </p>
    </form>
  </section>
</template>

<style scoped>
/* Login-specific layout. Shared styles stay in main.css. */
.login-page {
  max-width: 460px;
  margin: 40px auto;
}

.brand {
  margin-bottom: 24px;
  text-align: center;
}

.brand h1 {
  margin: 0;
  font-size: 32px;
  color: #087f74;
}

.brand p,
.subtitle {
  color: #546b6e;
}

.login-form {
  padding: 28px;
  background: white;
  color: #142d32;
  border: 1px solid #dce7e4;
  border-radius: 12px;
}

.login-form h2 {
  margin: 0 0 8px;
  font-size: 26px;
}

.subtitle {
  margin: 0 0 24px;
}

.form-group {
  display: grid;
  gap: 8px;
  margin-bottom: 20px;
}

label {
  font-weight: 600;
}

input {
  width: 100%;
  min-width: 0;
}

input:focus-visible,
button:focus-visible {
  outline: 2px solid #087f74;
  outline-offset: 3px;
}

.submit-button {
  width: 100%;
}

.status-message {
  color: #087f74;
  overflow-wrap: anywhere;
}

.status-message.error {
  color: #b93838;
}

.register-prompt {
  margin: 20px 0 0;
  text-align: center;
  color: #546b6e;
}

.text-button {
  padding: 4px;
  background: transparent;
  border: none;
  color: #087f74;
  font-weight: 600;
  text-decoration: underline;
}
</style>