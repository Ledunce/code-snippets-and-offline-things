<script setup>
import { ref } from "vue";

const API_URL = import.meta.env.VITE_API_BASE_URL;

// App.vue handles navigation after these events.
const emit = defineEmits(["registered", "login"]);

const regName = ref("");
const regEmail = ref("");
const regPassword = ref("");
const confirmPassword = ref("");

const statusMessage = ref("");
const fieldErrors = ref([]);
const hasError = ref(false);
const saving = ref(false);

async function registerPracticeAccount() {
  // Prevent repeated submissions while waiting.
  if (saving.value) return;

  statusMessage.value = "";
  fieldErrors.value = [];
  hasError.value = false;

  const name = regName.value.trim();
  const email = regEmail.value.trim();

  // Preserve passwords exactly as entered.
  const password = regPassword.value;
  const confirm = confirmPassword.value;

  if (!name || !email || !password || !confirm) {
    hasError.value = true;
    statusMessage.value = "Complete all registration fields.";
    return;
  }

  // The supplied backend measures password length in UTF-8 bytes.
  const passwordBytes =
    new TextEncoder().encode(password).length;

  if (passwordBytes < 8 || passwordBytes > 72) {
    hasError.value = true;
    statusMessage.value =
      "Password must be 8–72 bytes. For this practice, use English letters, numbers and symbols.";
    return;
  }

  if (password !== confirm) {
    hasError.value = true;
    statusMessage.value = "Passwords do not match.";
    return;
  }

  saving.value = true;
  statusMessage.value = "Creating your account...";

  try {
    if (!API_URL) {
      throw new Error(
        "API URL is missing. Check .env.local and restart Vite."
      );
    }

    // Registration does not require a Bearer token.
    const response = await fetch(
      API_URL + "?resource=register",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name,
          email,
          password,

          // This field name must match the API documentation.
          password_confirmation: confirm
        })
      }
    );

    const result = await response.json();

    if (!response.ok) {
      // Collect backend field messages, including duplicate email.
      fieldErrors.value =
        Object.values(result.errors || {}).flat();

      throw new Error(
        result.message || "Unable to create your account."
      );
    }

    regPassword.value = "";
    confirmPassword.value = "";
    statusMessage.value = "Account created. Please log in.";

    // Notify App.vue after successful registration.
    // There must be no return statement before this line.
    emit("registered");
  } catch (error) {
    hasError.value = true;
    statusMessage.value =
      error.message || "Unable to register. Please try again.";
  } finally {
    saving.value = false;
  }
}
</script>

<template>
  <section class="register-page">
    <header class="brand">
      <h1>GearDesk</h1>
      <p>Equipment rental workspace</p>
    </header>

    <form
      class="register-form"
      @submit.prevent="registerPracticeAccount"
    >
      <h2>Create an account</h2>
      <p class="subtitle">Join your team on GearDesk.</p>

      <div class="form-group">
        <label for="register-name">Full name</label>

        <input
          id="register-name"
          v-model="regName"
          name="name"
          type="text"
          autocomplete="name"
          maxlength="80"
          :disabled="saving"
          required
        />
      </div>

      <div class="form-group">
        <label for="register-email">Email address</label>

        <input
          id="register-email"
          v-model="regEmail"
          name="email"
          type="email"
          autocomplete="email"
          maxlength="190"
          :disabled="saving"
          required
        />
      </div>

      <div class="form-group">
        <label for="register-password">Password</label>

        <input
          id="register-password"
          v-model="regPassword"
          name="password"
          type="password"
          autocomplete="new-password"
          :disabled="saving"
          required
        />
      </div>

      <div class="form-group">
        <label for="confirm-password">Confirm password</label>

        <input
          id="confirm-password"
          v-model="confirmPassword"
          name="password_confirmation"
          type="password"
          autocomplete="new-password"
          :disabled="saving"
          required
        />
      </div>

      <!-- Display validation and API messages inside the form. -->
      <p
        v-if="statusMessage"
        class="status-message"
        :class="{ error: hasError }"
        role="status"
      >
        {{ statusMessage }}
      </p>

      <ul v-if="fieldErrors.length" class="field-errors">
        <li
          v-for="(message, index) in fieldErrors"
          :key="index"
        >
          {{ message }}
        </li>
      </ul>

      <!-- The form's submit event calls the function. -->
      <button
        class="submit-button"
        type="submit"
        :disabled="saving"
      >
        {{ saving ? "Creating account..." : "Create account" }}
      </button>

      <p class="login-prompt">
        Already have an account?

        <button
          class="text-button"
          type="button"
          :disabled="saving"
          @click="emit('login')"
        >
          Log in
        </button>
      </p>
    </form>
  </section>
</template>

<style scoped>
/* Registration-specific layout. Shared styles stay in main.css. */
.register-page {
  max-width: 460px;
  margin: 40px auto;
}

.brand {
  margin-bottom: 24px;
  text-align: center;
}

.brand h1 {
  margin: 0;
  font-size: 32px;
  color: #087f74;
}

.brand p,
.subtitle {
  color: #546b6e;
}

.register-form {
  padding: 28px;
  background: white;
  color: #142d32;
  border: 1px solid #dce7e4;
  border-radius: 12px;
}

.register-form h2 {
  margin: 0 0 8px;
  font-size: 26px;
}

.subtitle {
  margin: 0 0 24px;
}

.form-group {
  display: grid;
  gap: 8px;
  margin-bottom: 20px;
}

label {
  font-weight: 600;
}

input {
  width: 100%;
  min-width: 0;
}

input:focus-visible,
button:focus-visible {
  outline: 2px solid #087f74;
  outline-offset: 3px;
}

.submit-button {
  width: 100%;
}

.status-message {
  color: #087f74;
  overflow-wrap: anywhere;
}

.status-message.error,
.field-errors {
  color: #b93838;
}

.field-errors {
  padding-left: 20px;
}

.login-prompt {
  margin: 20px 0 0;
  text-align: center;
  color: #546b6e;
}

.text-button {
  padding: 4px;
  background: transparent;
  border: none;
  color: #087f74;
  font-weight: 600;
  text-decoration: underline;
}
</style>