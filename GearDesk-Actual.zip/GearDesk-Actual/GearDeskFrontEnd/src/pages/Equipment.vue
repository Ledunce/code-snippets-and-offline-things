<script setup>
import { ref, onMounted } from "vue";
import { token, currentUser } from "../auth.js";

const API_URL = import.meta.env.VITE_API_BASE_URL;
const emit = defineEmits(["logout"]);
const currentPage = ref(1);
const totalPages = ref(0);
const itemsPerPage = 5;

const equipment = ref([]);
const totalEquipment = ref(0);

const loading = ref(false);
const hasLoaded = ref(false);
const hasError = ref(false);
const statusMessage = ref("");

// Clear private data and ask the parent to return to Login.
function endExpiredSession() {
  equipment.value = [];
  totalEquipment.value = 0;
  hasLoaded.value = false;

  token.value = "";
  currentUser.value = null;
  sessionStorage.removeItem("geardesk_token");

  statusMessage.value = "Please log in again.";
  emit("logout");

    currentPage.value = 1;
    totalPages.value = 0;
}

async function getEquipment() {
  // Prevent repeated requests while one is running.
  if (loading.value) return;

  loading.value = true;
  hasLoaded.value = false;
  hasError.value = false;
  statusMessage.value = "Loading equipment...";

  // Remember which session started this request.
  const requestToken = token.value;

  try {
    if (!requestToken) {
      endExpiredSession();
      return;
    }

    if (!API_URL) {
      throw new Error(
        "API URL is missing. Check .env.local and restart Vite."
      );
    }

    // The backend selects page 1 with five records.
        const response = await fetch(
        API_URL +
            "?resource=equipment&page=" + currentPage.value +
            "&per_page=" + itemsPerPage,
        {
            headers: {
            Authorization: "Bearer " + requestToken
            }
        }
        );

    // Ignore an old response if the user changed sessions.
    if (token.value !== requestToken) return;

    if (response.status === 401) {
      endExpiredSession();
      return;
    }

    const result = await response.json();

    // Reading JSON also takes time, so check again.
    if (token.value !== requestToken) return;

    // fetch() does not automatically throw for HTTP errors.
    if (!response.ok) {
      throw new Error(
        result.message || "Unable to load equipment."
      );
    }

    // Expected response:
    // { data: [...], meta: { total: 17, ... } }
    if (
      !Array.isArray(result.data) ||
      !Number.isInteger(result.meta?.total) ||
      result.meta.total < 0
    ) {
      throw new Error(
        "The API returned an unexpected equipment response."
      );
    }

// Save the current page's records.
equipment.value = result.data;

// Save pagination information.
totalEquipment.value = result.meta.total;
currentPage.value = result.meta.page;
totalPages.value = result.meta.total_pages;

// Allow the template to display the table.
hasLoaded.value = true;
statusMessage.value = "Equipment loaded.";
  } catch (error) {
    if (token.value !== requestToken) return;

    // A server/network failure does not invalidate the token.
    hasError.value = true;
    statusMessage.value =
      error.message || "Unable to load equipment.";
  } finally {
    // Always allow another attempt after the request ends.
    loading.value = false;
  }
}

// Display prices in pesos with two decimal places.
function formatPrice(value) {
  return new Intl.NumberFormat("en-PH", {
    style: "currency",
    currency: "PHP"
  }).format(value);
}

// Automatically fetch records when this component appears.
onMounted(getEquipment);


async function changePage(page) {
  // Prevent requests while loading or outside valid boundaries.
  if (
    loading.value ||
    page < 1 ||
    page > totalPages.value
  ) {
    return;
  }

  currentPage.value = page;

  // Fetch the five records for the selected page.
  await getEquipment();
}
</script>

<template>
  <section>
    <header>
      <h1>Equipment inventory</h1>

      <p v-if="currentUser">
        Signed in as {{ currentUser.name }}
      </p>

      <!-- The parent handles backend logout and navigation. -->
      <button type="button" @click="emit('logout')">
        Log out
      </button>
    </header>

    <button
      type="button"
      :disabled="loading"
      @click="getEquipment"
    >
      {{
        loading
          ? "Loading..."
          : hasError
            ? "Retry"
            : "Refresh equipment"
      }}
    </button>

    <!-- Visible even when there are no equipment records. -->
    <p role="status">{{ statusMessage }}</p>

    <template v-if="hasLoaded">
      <p v-if="equipment.length === 0">
        No equipment found.
      </p>

      <div v-else class="table-container">
        <table>
          <thead>
            <tr>
              <th scope="col">Equipment</th>
              <th scope="col">Category</th>
              <th scope="col">Daily rate</th>
              <th scope="col">Available units</th>
              <th scope="col">Status</th>
            </tr>
          </thead>

          <tbody>
            <tr v-for="item in equipment" :key="item.id">
              <td>{{ item.name }}</td>
              <td>{{ item.category_name }}</td>
              <td>{{ formatPrice(item.daily_rate) }}</td>
              <td>{{ item.available_units }}</td>
              <td>
                {{
                  item.available_units === 0
                    ? "Out of stock"
                    : "Available"
                }}
              </td>
            </tr>
          </tbody>
        </table>
<!--Pagination---->
                <p>
            Showing
            {{ (currentPage - 1) * itemsPerPage + 1 }}
            to
            {{ (currentPage - 1) * itemsPerPage + equipment.length }}
            of {{ totalEquipment }} equipment items.
            </p>

            <nav aria-label="Equipment pagination">
            <button
                type="button"
                :disabled="loading || currentPage <= 1"
                @click="changePage(currentPage - 1)"
            >
                Previous
            </button>

            <span>
                Page {{ currentPage }} of {{ totalPages }}
            </span>

            <button
                type="button"
                :disabled="loading || currentPage >= totalPages"
                @click="changePage(currentPage + 1)"
            >
                Next
            </button>
            </nav>
      </div>
    </template>
  </section>
</template>

<style scoped>
.table-container {
  overflow-x: auto;
}

table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  padding: 12px;
  border-bottom: 1px solid #dce7e4;
  text-align: left;
}

th {
  background: #f3f6f5;
}

button {
  margin: 0 8px 12px 0;
}
</style>