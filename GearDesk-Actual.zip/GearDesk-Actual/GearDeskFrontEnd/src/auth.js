import { ref } from "vue";

// Shared access token used in authenticated API requests.
// Empty means no token has been loaded yet.
export const token = ref("");

// Shared user details returned by the backend.
// Null means no user has been loaded yet.
export const currentUser = ref(null);