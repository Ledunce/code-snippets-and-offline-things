Open OPEN-FIRST.html in a browser, or Frontend-Errors-and-Fixes.md in VS Code.
Use Ctrl+F to find an error or function.
CODE/OBSERVED/CHECK/PREVENT labels explain the evidence level.
This is a documentation pack, not a replacement frontend/backend project.
