# Frontend Errors and Fixes - Offline Reference

Vue / Vite / JSON Server / GearDesk PHP API. Prepared 28 October 2026.

Use Ctrl+F to find the exact error, filename, status code or function name. Start with the browser Console and Network request; fix the first relevant error, then repeat the same action.

This guide records code defects and symptoms from our conversation. It also labels diagnostic/preventive cases so a possible explanation is not mistaken for a confirmed root cause.

## Status labels

- CODE: Confirmed in code shown during our practice; live execution is not implied.
- OBSERVED: Observed symptom with the explanation established in our discussion.
- CHECK: Diagnostic checklist; the exact local cause was not confirmed for every occurrence.
- PREVENT: Preventive preparation, not an observed failure on your computer.

## Quick lookup

| ID | Symptom | Status | Location |
| --- | --- | --- | --- |
| E01 | npm run api: Missing script | CODE | package.json; terminal project folder |
| E02 | Red underline in package.json | CODE | package.json > scripts |
| E03 | ERR_SSL_PROTOCOL_ERROR with localhost:3000 | OBSERVED | Fetch URL; frontend API environment value |
| E04 | Request goes to the wrong resource or returns HTML/404 | CHECK | API base URL and each fetch endpoint |
| E05 | Failed to fetch, CORS error, or unreachable API | CHECK | Network, Apache/MySQL, backend ALLOWED_ORIGINS, API URL |
| E06 | API unavailable but page has no useful message | CODE | Equipment.vue / earlier App.vue template |
| E07 | POST saves, then JavaScript reports failure | CODE | Earlier supply App.vue > addSupplies |
| E08 | Undefined bindings: Adding, cancel, currentUser, showAddModal | CODE | Earlier supply template; registration template; Equipment.vue imports |
| E09 | Add button disappears when the list is empty; duplicated modals | CODE | Earlier supply App.vue template |
| E10 | Modal closes even when saving fails | CODE | Add/Edit submit button and async save handler |
| E11 | Records do not load automatically | CODE | Vue component script |
| E12 | Loading equipment remains visible; request reaches the API but table is blank | CHECK | Equipment.vue > getEquipment and template conditions |
| E13 | Wrapped API response does not render | CHECK | Equipment.vue > getEquipment |
| E14 | Only five of 17 items are visible | CODE | Equipment.vue > request URL and pagination controls |
| E15 | Empty final page after deletion; Page 1 of 0 | CHECK | Equipment.vue / earlier supply pagination |
| E16 | Search changes unexpectedly while paging; sort seems to do nothing | CHECK | Equipment.vue search/sort state; practice PHP API |
| E17 | A category disappears; Stationary fails to match Stationery | CODE | Earlier supply App.vue > category list and validation |
| E18 | Fractional/negative stock or blank numeric values accepted | CODE | Add/Edit validation |
| E19 | Display changes but the update does not persist after refresh | CHECK | Earlier product/supply update handler |
| E20 | DELETE succeeds, then JSON parsing fails | CHECK | Equipment.vue > delete handler |
| E21 | Registration succeeds but does not switch to Login | CODE | Register.vue > registerPracticeAccount |
| E22 | Password visible; email uses number binding; passwords are changed | CODE | Login.vue and Register.vue inputs / validation |
| E23 | Submit runs through two handlers; required fields still reach the API | CODE | Login.vue / Register.vue submit button |
| E24 | API errors are hidden or replaced by a vague message | CODE | Login.vue / Register.vue catch block and template |
| E25 | Unprocessable Content confused with browser validation | OBSERVED | Network > status/response; form constraints |
| E26 | Logout only returns to Login; a token remains usable | CODE | App.vue > Equipment @logout handler |
| E27 | Reload loses login; Equipment can be opened while signed out | CODE | auth.js and App.vue |
| E28 | Page stays black / stylesheet changes seem ineffective | CHECK | src/main.js; global main.css or style.css; base.css |
| E29 | Offline computer has no Git, Vite or installed packages | PREVENT | Windows installation and local project backup |

## E01 - npm run api: Missing script

**Status:** CODE  
**Where:** package.json; terminal project folder

**Cause / diagnosis:** The project did not define an api script, or the terminal was in a different project.

**Fix:** Run npm run to inspect available scripts. For the JSON Server practice, add the api entry below. GearDesk PHP runs through XAMPP, so it does not need an npm api script.

```json
"scripts": {
  "dev": "vite",
  "build": "vite build",
  "preview": "vite preview",
  "api": "json-server db.json"
}
```

**Verify:** In the JSON Server project, npm run api starts the local server. In GearDesk, Apache/MySQL and the health endpoint work.

## E02 - Red underline in package.json

**Status:** CODE  
**Where:** package.json > scripts

**Cause / diagnosis:** The preview entry was missing its comma before the api entry. JSON also requires quoted keys and values.

**Fix:** Use the scripts block in E01; the comma after preview separates the next property. Keep the rest of the existing package.json.

**Verify:** VS Code shows no JSON syntax error and npm run lists the scripts.

## E03 - ERR_SSL_PROTOCOL_ERROR with localhost:3000

**Status:** OBSERVED  
**Where:** Fetch URL; frontend API environment value

**Cause / diagnosis:** The earlier request used https://127.0.0.1:3000 against a local server serving plain HTTP.

**Fix:** Use the scheme actually provided by the API. Our local JSON Server and XAMPP examples use http://. Hosted APIs may require HTTPS.

```js
const url = "http://127.0.0.1:3000/products/1";
```

**Verify:** Network shows the intended endpoint responding without the SSL protocol error.

## E04 - Request goes to the wrong resource or returns HTML/404

**Status:** CHECK  
**Where:** API base URL and each fetch endpoint

**Cause / diagnosis:** Our practices use different contracts: JSON Server uses /supplies or /products; GearDesk uses index.php?resource=equipment. A singular/plural mismatch or wrong Apache path can hit another route.

**Fix:** Read the supplied endpoint exactly. Check Network > Request URL and Response. Preserve the correct resource name, query separator, ID and Apache port.

```js
// GearDesk
const url = API_URL + "?resource=equipment&page=1&per_page=5";
// Earlier JSON Server practice: http://localhost:3000/supplies/1
```

**Verify:** The Response tab contains the documented JSON, not an Apache/Vite HTML page.

## E05 - Failed to fetch, CORS error, or unreachable API

**Status:** CHECK  
**Where:** Network, Apache/MySQL, backend ALLOWED_ORIGINS, API URL

**Cause / diagnosis:** A failed browser fetch can result from a stopped API, wrong URL/port, or a real CORS configuration problem. The browser message alone did not establish every root cause in our attempts.

**Fix:** Open the health URL; verify services and port. Check the exact frontend origin in the backend allowlist. GearDesk permits Authorization and Content-Type in CORS preflight. Use the local hostname consistently. Do not use mode: no-cors to hide the error.

**Verify:** Health responds, preflight succeeds where applicable, and the browser can read the API JSON.

## E06 - API unavailable but page has no useful message

**Status:** CODE  
**Where:** Equipment.vue / earlier App.vue template

**Cause / diagnosis:** Some status messages were inside pagination or record-dependent blocks, so an initial failure with zero records hid them.

**Fix:** Render the status message outside the record list/pagination, and show form failures inside the active modal/form. Provide Retry for loading failures.

```html
<p role="status">{{ statusMessage }}</p>
```

**Verify:** Stop the API before initial load. A visible error and usable Retry remain on the page.

## E07 - POST saves, then JavaScript reports failure

**Status:** CODE  
**Where:** Earlier supply App.vue > addSupplies

**Cause / diagnosis:** The script used showAddModal = false even though showAddModal was declared as a const holding a Vue ref. That assignment can throw after the POST already committed.

**Fix:** Use showAddModal.value = false in script. Inspect/refetch records before retrying an uncertain save, to avoid accidentally adding it twice.

```js
supplies.value.push(createdSupply);
showAddModal.value = false;
```

**Verify:** Add once: the modal closes without an exception, and one new record survives refresh.

## E08 - Undefined bindings: Adding, cancel, currentUser, showAddModal

**Status:** CODE  
**Where:** Earlier supply template; registration template; Equipment.vue imports

**Cause / diagnosis:** The snippets included undeclared bindings and leftovers from other forms. One Equipment version cleared currentUser without importing it.

**Fix:** Use the actual pending ref (saving/updating). Import currentUser from auth.js where used. Remove unrelated modal variables from Register.vue; use its parent navigation event instead.

```js
import { token, currentUser } from "../auth.js";
// Template example: :disabled="saving"
```

**Verify:** Console has no undefined-variable/binding errors during add, edit, registration or a 401 response.

## E09 - Add button disappears when the list is empty; duplicated modals

**Status:** CODE  
**Where:** Earlier supply App.vue template

**Cause / diagnosis:** The Add action and Add/Edit modal markup were inside v-for, so each record created another copy. An empty array rendered none.

**Fix:** Put the page-level Add button and one instance of each modal outside v-for. Keep each row's Edit/Delete buttons inside its row.

**Verify:** An empty dataset still has Add. Opening Edit creates one active modal.

## E10 - Modal closes even when saving fails

**Status:** CODE  
**Where:** Add/Edit submit button and async save handler

**Cause / diagnosis:** A click handler closed the modal immediately, before the API outcome was known.

**Fix:** Let the form submit invoke the async handler. Close only after a successful response. Leave entered values and an error message visible after a failure.

```html
<form @submit.prevent="addSupplies">
  <button type="submit" :disabled="saving">Save</button>
</form>
```

**Verify:** Stop the API with a filled form open; Save preserves the form and its inputs.

## E11 - Records do not load automatically

**Status:** CODE  
**Where:** Vue component script

**Cause / diagnosis:** An earlier component used document.addEventListener("DOMContentLoaded", getSupplies). The whole-document event may already have fired before that component appears.

**Fix:** Register Vue's onMounted hook during setup and pass the function reference.

```js
import { onMounted } from "vue";
onMounted(getEquipment);
```

**Verify:** Open the component without pressing Load/Get: a request is sent automatically.

## E12 - Loading equipment remains visible; request reaches the API but table is blank

**Status:** CHECK  
**Where:** Equipment.vue > getEquipment and template conditions

**Cause / diagnosis:** This symptom occurred, but the exact edited line causing it was not confirmed. Possible checks include a pending request, response shape, hasLoaded remaining false, a JavaScript error, or a deliberate early return after the session changed.

**Fix:** Check Network completion/status and Console. After successful response handling, assign records/metadata and set hasLoaded true. Reset loading in finally. Verify the table's v-if and v-for. Keep the session-change guard; do not remove it merely to force a display.

```js
// In the existing success block:
equipment.value = result.data;
totalEquipment.value = result.meta.total;
currentPage.value = result.meta.page;
totalPages.value = result.meta.total_pages;
hasLoaded.value = true;
statusMessage.value = "Equipment loaded.";
// In finally: loading.value = false;
```

**Verify:** Temporarily display equipment, hasLoaded and loading outside conditional blocks; remove these debug outputs after fixing the issue.

## E13 - Wrapped API response does not render

**Status:** CHECK  
**Where:** Equipment.vue > getEquipment

**Cause / diagnosis:** JSON Server returned an array in earlier exercises; GearDesk returns { data: [...], meta: {...} }. The wrong assignment gives the template the wrong data shape.

**Fix:** Use the exact response path documented by the API. In GearDesk assign result.data to equipment and result.meta to pagination state.

```js
equipment.value = result.data;
```

**Verify:** The equipment ref is an array, and its first item has the documented fields. Inspect Network > Response.

## E14 - Only five of 17 items are visible

**Status:** CODE  
**Where:** Equipment.vue > request URL and pagination controls

**Cause / diagnosis:** The initial example requested a fixed page 1. The API correctly returned only that page.

**Fix:** Send currentPage and per_page=5. Add Previous/Next controls and read totals from meta. Render the returned page directly; it has already been paginated.

**Verify:** Original dataset: pages contain 5, 5, 5 and 2 items. Network changes page=1 to page=2, etc.

## E15 - Empty final page after deletion; Page 1 of 0

**Status:** CHECK  
**Where:** Equipment.vue / earlier supply pagination

**Cause / diagnosis:** Deleting the final record on a page can make its page number invalid. Zero matching records legitimately produce total_pages=0.

**Fix:** After deletion/refetch, move to the last valid page and fetch again if necessary. Show an empty state when total is zero, with pagination hidden/disabled. Keep Add/search controls available.

**Verify:** Delete all records on the final page; the app returns to a valid page. A zero-match search does not show Page 1 of 0.

## E16 - Search changes unexpectedly while paging; sort seems to do nothing

**Status:** CHECK  
**Where:** Equipment.vue search/sort state; practice PHP API

**Cause / diagnosis:** Typing a draft query should not silently change applied filters on Next. The original PHP API searches by name and filters by category but has fixed ID ordering; arbitrary sort parameters are ignored unless our extension was applied.

**Fix:** Keep appliedSearch/appliedSort separate from input controls. Apply resets page to 1. Reuse applied values for all page requests. For global sorting, use supported backend parameters or our practice extension; sorting only five returned rows orders just that page.

**Verify:** Search, choose a supported sort, then Next. The request retains those values and the records stay globally ordered.

## E17 - A category disappears; Stationary fails to match Stationery

**Status:** CODE  
**Where:** Earlier supply App.vue > category list and validation

**Cause / diagnosis:** Building options from existing records means deleting the last record in a category removes that option. The earlier fixed list also had a spelling mismatch.

**Fix:** For the supply exercise, use the documented fixed values Stationery/Paper/Accessories. For GearDesk, fetch the category endpoint and send numeric category_id values.

**Verify:** Category choices remain available when equipment/supplies are empty, and saved category values match the API.

## E18 - Fractional/negative stock or blank numeric values accepted

**Status:** CODE  
**Where:** Add/Edit validation

**Cause / diagnosis:** Some earlier checks used only isFinite or only rejected negative values. Number("") also becomes 0, so conversion alone cannot prove that a required field was filled.

**Fix:** Check missing values before conversion. Validate stock as an integer >= 0 (GearDesk maximum 9999). Validate GearDesk rate as > 0, at most two decimals and <= 999999.99. Send numbers rather than numeric strings.

```js
// After checking the required input and converting it:
if (!Number.isInteger(stock) || stock < 0) {
  throw new Error("Stock must be a whole number of zero or more.");
}
```

**Verify:** Reject blank rate, zero/negative rate, and negative/fractional stock. Accept zero stock.

## E19 - Display changes but the update does not persist after refresh

**Status:** CHECK  
**Where:** Earlier product/supply update handler

**Cause / diagnosis:** Changing a local variable or DOM text only changes the browser. The saved response from a successful API mutation is what confirms the persisted values.

**Fix:** Send the documented POST/PATCH/PUT request, check success, then use the returned record or refetch. In Vue, update reactive state and let the template render it. Copy the whole edit flow, not only its DOM update.

**Verify:** Change a field, refresh, and fetch again. The saved value remains.

## E20 - DELETE succeeds, then JSON parsing fails

**Status:** CHECK  
**Where:** Equipment.vue > delete handler

**Cause / diagnosis:** GearDesk returns HTTP 204 with no response body. Calling response.json() unconditionally after success attempts to parse an empty body.

**Fix:** Handle a protected-request 401 through the session handler. Parse an error body for a failed request; on successful 204, refetch without parsing JSON.

```js
if (response.status === 401) {
  endExpiredSession();
  return;
}
if (!response.ok) {
  const result = await response.json();
  throw new Error(result.message || "Unable to delete.");
}
await getEquipment();
```

**Verify:** The correct item disappears, no parse error occurs, and deletion persists after refresh.

## E21 - Registration succeeds but does not switch to Login

**Status:** CODE  
**Where:** Register.vue > registerPracticeAccount

**Cause / diagnosis:** return result appeared before emit("registered"). Every statement after that return was unreachable.

**Fix:** Emit registered after the successful response. App.vue must listen with @registered="registrationFinished". Registration in this practice API creates an account without returning a token.

```js
if (!response.ok) {
  throw new Error(result.message || "Unable to register.");
}
emit("registered");
// Any optional return belongs AFTER the emit.
```

**Verify:** A new account produces 201, then Login appears. The new credentials can log in.

## E22 - Password visible; email uses number binding; passwords are changed

**Status:** CODE  
**Where:** Login.vue and Register.vue inputs / validation

**Cause / diagnosis:** Passwords used type=text; registration email used v-model.number; passwords and confirmation were trimmed. Those conversions can expose or change the entered value, and a numeric-looking email can cease being a string.

**Fix:** Use type=password and plain v-model for passwords; use type=email and plain v-model for email. Trim names/emails but preserve passwords exactly. Compare the raw password and confirmation.

```js
const email = regEmail.value.trim();
const password = regPassword.value;
const confirm = confirmPassword.value;
```

**Verify:** Passwords are masked. A mismatch is rejected before POST. An email beginning with digits remains a string.

## E23 - Submit runs through two handlers; required fields still reach the API

**Status:** CODE  
**Where:** Login.vue / Register.vue submit button

**Cause / diagnosis:** The forms had @submit.prevent and their submit buttons also had @click calling the same function. The click handler can run before form constraint validation. The pending guard can prevent duplicate requests, so duplicates are not guaranteed.

**Fix:** Use one form submit handler and a type=submit button. Keep the saving guard and use type=button for navigation/Cancel.

```html
<form @submit.prevent="login">
  <input v-model="email" type="email" required />
  <input v-model="password" type="password" required />
  <button type="submit" :disabled="saving">Log in</button>
</form>
```

**Verify:** Blank required fields produce a browser message and no POST. A valid submission produces one login/registration POST.

## E24 - API errors are hidden or replaced by a vague message

**Status:** CODE  
**Where:** Login.vue / Register.vue catch block and template

**Cause / diagnosis:** Registration replaced useful API messages with Account may not be valid, and forms did not display statusMessage.

**Fix:** Display result.message and any result.errors field messages. Catch network failures too. Keep ordinary form values on failure and reset saving in finally. Remove invalid </input> closing tags while correcting the template.

```js
// Existing catch block:
statusMessage.value = error.message || "Unable to complete the request.";
// Existing template:
// <p role="status">{{ statusMessage }}</p>
```

**Verify:** Wrong password 401, duplicate email 409 and invalid input 422 each produce a useful visible message.

## E25 - Unprocessable Content confused with browser validation

**Status:** OBSERVED  
**Where:** Network > status/response; form constraints

**Cause / diagnosis:** You reported an "unprocessable entry" result. If Network shows HTTP 422, the request reached backend validation; that does not demonstrate that the browser blocked submission. The exact status was not independently inspected. Browser and server email rules can differ.

**Fix:** Test native validation separately: clear a required field and submit, expecting no POST. For 422, read the API's message/errors and correct the documented payload.

**Verify:** You can distinguish a browser popup/no request from a server 422 with a JSON response.

## E26 - Logout only returns to Login; a token remains usable

**Status:** CODE  
**Where:** App.vue > Equipment @logout handler

**Cause / diagnosis:** The original parent handler only set currentPage to login. It neither revoked the server token nor cleared shared/browser state.

**Fix:** For normal logout, POST logout with Authorization before clearing the token. After success (or already-invalid 401), clear token, currentUser and sessionStorage and show Login. If Equipment already cleared an expired token, return to Login without sending an empty-token logout request.

**Verify:** Session Storage loses geardesk_token, private data is hidden, and the old token receives 401 if reused.

## E27 - Reload loses login; Equipment can be opened while signed out

**Status:** CODE  
**Where:** auth.js and App.vue

**Cause / diagnosis:** auth.js starts with empty refs on each fresh app load, and the original navigation exposed Equipment without a session check.

**Fix:** App.vue restores the saved token, verifies GET me, then reveals Equipment. Guard both navigation and rendering. On protected-request 401, clear session/private data. On network/503 verification failure, retain the token and offer Retry.

**Verify:** A valid token survives refresh through verification; an invalid token leads to Login; a temporary server outage offers Retry.

## E28 - Page stays black / stylesheet changes seem ineffective

**Status:** CHECK  
**Where:** src/main.js; global main.css or style.css; base.css

**Cause / diagnosis:** The black background was reported; the actual imported CSS was not supplied, so a specific rule was not confirmed. A starter dark theme was a likely place to check. Scoped nav styles do not define the global body background.

**Fix:** Inspect which CSS main.js imports. Set shared body/root colors in that global file. Keep page forms/cards in their own scoped styles. Check DevTools Computed styles if another rule still wins.

```css
:root { color-scheme: light; }
body {
  margin: 0;
  background: #f3f6f5;
  color: #142d32;
}
```

**Verify:** The loaded global stylesheet sets the intended light page background and readable text.

## E29 - Offline computer has no Git, Vite or installed packages

**Status:** PREVENT  
**Where:** Windows installation and local project backup

**Cause / diagnosis:** This was preparation guidance, not a confirmed failure on the current computer. A VS Code extension or package manifest alone does not install Git or provide every npm dependency offline.

**Fix:** Keep installers/portable Git, the tested Vue project with node_modules, lockfile, PHP backend, SQL and docs locally. Check node -v, npm -v and git --version now. Avoid npm ci on your only offline copy: it removes node_modules before reinstalling.

**Verify:** Disconnect the Internet, restart the app/backend, log in, load data and build successfully.

## HTTP status cheat sheet

| Status | Meaning / action |
| --- | --- |
| 200 / 201 | Success; process the documented response before updating UI/navigation. |
| 204 | Success with no body; do not parse JSON. |
| 400 | Bad query or malformed JSON. |
| 401 on login | Wrong credentials; stay on Login with a message. |
| 401 on protected request | Missing/expired/revoked token; clear the session and return to Login. |
| 403 in our practice API | Frontend origin is not allowed; check its CORS configuration. |
| 404 | Wrong route or missing record. |
| 405 | Wrong HTTP method. |
| 409 on register | Email already exists. |
| 415 | Wrong JSON Content-Type. |
| 422 | Backend input validation rejected the payload. |
| 503 | Database/backend service unavailable; offer Retry. |
| No HTTP response | Inspect network reachability, CORS, DNS/port and Console. |

## First-time Git on a new computer

While online, obtain Git for Windows or its portable package. On an offline computer, use a copy already downloaded to the machine/USB. Restart VS Code and terminals after installation, then run git --version.

In a NEW project folder, initialize and configure project-local identity (replace the sample name/email):

```powershell
git init -b main
git config user.name "Your Name"
git config user.email "your-email@example.com"
```

Keep an existing repository/history if present. Before git add, ensure .gitignore excludes node_modules/, dist/, .env and .env.* while allowing a safe .env.example. Review staged files, then commit. Local Git commits work offline; remote operations require network access.

## Before adapting a snippet to the assessment

- Confirm the actual endpoint, method, writable fields, JSON types and response shape.
- Copy refs, handler, template, CSS and parent event wiring together.
- For the earlier supply update flow: src/App.vue -> openEditModal / editSupply; copy showEditModal, selectedSupply and its form, plus .modal / .editModal / .editSupply-card CSS from your corrected local copy.
- For auth/navigation: GearDesk src/App.vue, src/auth.js and src/pages/Login.vue / Register.vue.
- For loading/pagination/search: GearDesk src/pages/Equipment.vue.
- The old pasted supply source included defects corrected later; do not assume an old snapshot is your final working version.
- Preserve API-generated IDs. Do not assume consecutive IDs or substitute a manually computed new ID.
- A competition-style scenario is not confirmed until you read the actual supplied requirements.

## Official technical references to save while online

- Vue lifecycle: https://vuejs.org/guide/essentials/lifecycle.html
- Vue form bindings: https://vuejs.org/guide/essentials/forms.html
- Fetch: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
- Form submission: https://developer.mozilla.org/en-US/docs/Web/API/HTMLFormElement/submit_event
- npm ci: https://docs.npmjs.com/cli/v11/commands/npm-ci/
- Git for Windows: https://git-scm.com/install/windows

The HTML version has no external stylesheets, fonts, images or scripts. Download/extract it before disconnecting; cloud links alone are not an offline copy.
